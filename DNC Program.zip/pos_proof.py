# pos_proof.py
"""
Proof of Storage (PoS) demo utilities:
- Chunk a byte string (or file) and precompute per-chunk hashes.
- Issue random challenges: (chunk_index, salt), expected = H(chunk || salt).
- Verify responses.
No external deps; uses SHA-256. Educational only.
"""
import os
import hashlib
from dataclasses import dataclass, field
from typing import List

CHUNK_SIZE = 32 * 1024  # 32 KB

@dataclass
class StoredFragment:
    total_size: int
    chunk_size: int = CHUNK_SIZE
    chunk_hashes: List[bytes] = field(default_factory=list)

def _hash(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

def prepare_fragment_from_bytes(data: bytes) -> StoredFragment:
    chunk_hashes = []
    for i in range(0, len(data), CHUNK_SIZE):
        chunk_hashes.append(_hash(data[i:i+CHUNK_SIZE]))
    return StoredFragment(total_size=len(data), chunk_hashes=chunk_hashes)

def generate_challenge(fragment: StoredFragment):
    """Return (index, salt) for a random chunk challenge."""
    import random
    if not fragment.chunk_hashes:
        raise ValueError("Empty fragment")
    idx = random.randrange(0, len(fragment.chunk_hashes))
    salt = os.urandom(16)
    return idx, salt

def expected_response(fragment: StoredFragment, idx: int, chunk_bytes: bytes, salt: bytes) -> bytes:
    return _hash(chunk_bytes + salt)

def verify_response(fragment: StoredFragment, idx: int, salt: bytes, response_hash: bytes, chunk_bytes: bytes) -> bool:
    # Server verifies provided chunk matches committed chunk hash and response hash
    if idx < 0 or idx >= len(fragment.chunk_hashes):
        return False
    if _hash(chunk_bytes) != fragment.chunk_hashes[idx]:
        return False
    return expected_response(fragment, idx, chunk_bytes, salt) == response_hash
