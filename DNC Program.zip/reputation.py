# reputation.py
"""
Simple reputation & slashing:
- Start peers at score=100.
- Penalize on failures; reward on good behavior.
- Drop/bucket peers below threshold.
Persisted under ~/.diac_dnc/reputation.json
"""
import json
from pathlib import Path

DEFAULT_SCORE = 100
SLASH_FAIL = 10
REWARD_GOOD = 1
BAN_THRESHOLD = 60

class Reputation:
    def __init__(self, base_path: Path):
        self.file = base_path / "reputation.json"
        self.scores = {}
        self._load()

    def _load(self):
        if self.file.exists():
            try:
                self.scores = json.loads(self.file.read_text(encoding="utf-8"))
            except Exception:
                self.scores = {}
        else:
            self.scores = {}
            self._save()

    def _save(self):
        try:
            self.file.write_text(json.dumps(self.scores, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _key(self, ip: str, port: int) -> str:
        return f"{ip}:{port}"

    def get(self, ip: str, port: int) -> int:
        return int(self.scores.get(self._key(ip, port), DEFAULT_SCORE))

    def reward(self, ip: str, port: int, amount: int = REWARD_GOOD):
        k = self._key(ip, port)
        self.scores[k] = self.get(ip, port) + amount
        self._save()

    def slash(self, ip: str, port: int, amount: int = SLASH_FAIL):
        k = self._key(ip, port)
        self.scores[k] = max(0, self.get(ip, port) - amount)
        self._save()

    def banned(self, ip: str, port: int) -> bool:
        return self.get(ip, port) < BAN_THRESHOLD

    def snapshot(self):
        return dict(self.scores)
