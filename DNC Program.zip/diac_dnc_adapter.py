# diac_dnc_adapter.py
import threading
import time
import json
import socket
from datetime import datetime
from pathlib import Path

from diac_dnc_client_core import DNCAuxiliary

# Optional modules used by GUI "Security" tab
try:
    from reputation import Reputation
except Exception:
    # Fallback stub if module missing
    class Reputation:
        def __init__(self, path: str = None):
            self._scores = {}
        def reward(self, ip, port, amount=1):
            key = f"{ip}:{int(port)}"
            self._scores[key] = self._scores.get(key, 0) + int(amount)
        def slash(self, ip, port, amount=10):
            key = f"{ip}:{int(port)}"
            self._scores[key] = self._scores.get(key, 0) - int(amount)
        def snapshot(self):
            return dict(self._scores)

try:
    from pos_proof import generate_challenge, verify_response, expected_response, CHUNK_SIZE
except Exception:
    # Minimal fallback for PoS demo
    import hashlib, os
    CHUNK_SIZE = 32 * 1024
    def generate_challenge(fragment: bytes):
        if not fragment:
            raise ValueError("empty fragment")
        idx = 0
        salt = os.urandom(16)
        return idx, salt
    def expected_response(fragment: bytes, idx: int, chunk: bytes, salt: bytes):
        h = hashlib.sha256(); h.update(chunk or b""); h.update(salt or b"")
        return h.digest()
    def verify_response(fragment: bytes, idx: int, salt: bytes, response: bytes, chunk: bytes):
        return expected_response(fragment, idx, chunk, salt) == response

DEFAULT_DIAC_PORT = 369  # Central DIAC "network" port

class DNCAdapter:
    """Adapter between the GUI and the core DNC functionality, with real TCP ping and LAN discovery.
       Extended with Reputation & PoS helpers used by the Security tab.
    """
    
    def __init__(self):
        self.dnc = None
        self.mining_thread = None
        self.mining_active = False
        self.load_path = Path.home() / '.diac_dnc'
        self.load_path.mkdir(exist_ok=True)

        # Reputation store
        try:
            # Pass a directory Path; reputation.py can do base_path / 'reputation.json'
            self.reputation = Reputation(base_path=self.load_path)
        except TypeError:
            try:
                self.reputation = Reputation(self.load_path)
            except TypeError:
                self.reputation = Reputation()


        # Local fragment buffer for PoS self-demo
        self._fragment_data = None  # type: ignore

        # Ping server
        self.listen_port = None
        self._server_thread = None
        self._server_socket = None

        # Multicast discovery
        self._mc_send_thread = None
        self._mc_recv_thread = None
        self._stop_mc = threading.Event()
        self._multicast_group = ('239.255.124.69', 39369)  # LAN scope multicast
        self._hidden_id = None  # internal, not shown

    # ----------------- Network bootstrap -----------------
    def configure_network(self, port: int):
        """Start TCP ping server + start LAN discovery on the selected port (central or custom)."""
        self.start_ping_server(port)
        self.start_multicast_discovery(port)

    def start_ping_server(self, port: int):
        """Start the TCP server that answers pings on the given port.
           Also supports a simple peer-list exchange command.
        """
        if self._server_thread and self._server_thread.is_alive():
            return  # Already running
        self.listen_port = int(port)
        self._server_thread = threading.Thread(target=self._start_ping_server, daemon=True)
        self._server_thread.start()

    def _start_ping_server(self):
        try:
            self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_socket.bind(('0.0.0.0', self.listen_port))
            self._server_socket.listen()
            print(f"[DNCAdapter] Ping server listening on port {self.listen_port}")
            while True:
                conn, addr = self._server_socket.accept()
                try:
                    data = conn.recv(4096)
                    if data == b"ping":
                        conn.sendall(b"pong")
                    elif data == b"getpeerlist":
                        payload = json.dumps(self.get_peers()).encode("utf-8")
                        conn.sendall(payload)
                    # else: ignore
                finally:
                    conn.close()
        except Exception as e:
            print(f"[DNCAdapter] Ping server error: {e}")

    def _get_local_ip(self) -> str:
        try:
            # Discover outward-facing local IP (works without internet connection as well)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def start_multicast_discovery(self, port: int):
        """Start LAN multicast discovery. Nodes on the same LAN & port will auto-find each other."""
        if self._mc_send_thread and self._mc_send_thread.is_alive():
            return
        self._stop_mc.clear()
        self._mc_send_thread = threading.Thread(target=self._mc_sender, args=(int(port),), daemon=True)
        self._mc_recv_thread = threading.Thread(target=self._mc_receiver, args=(int(port),), daemon=True)
        self._mc_send_thread.start()
        self._mc_recv_thread.start()

    def stop_multicast_discovery(self):
        """Stop LAN discovery threads."""
        self._stop_mc.set()

    def _mc_sender(self, port: int):
        """Periodically announce our presence on LAN via multicast."""
        ttl_bin = (1).to_bytes(1, 'little')
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl_bin)
            ip = self._get_local_ip()
            while not self._stop_mc.is_set():
                # Message format: DNCHELLO ip port address
                addr = self.get_address() or ""
                msg = f"DNCHELLO {ip} {port} {addr}".encode('utf-8')
                s.sendto(msg, self._multicast_group)
                time.sleep(3)
        except Exception as e:
            print(f"[DNCAdapter] Multicast sender error: {e}")

    def _mc_receiver(self, port: int):
        """Listen for multicast announcements and add peers that share our selected port.
           After adding, request their peerlist and merge (peer-exchange).
        """
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('', self._multicast_group[1]))
            mreq = socket.inet_aton(self._multicast_group[0]) + socket.inet_aton('0.0.0.0')
            s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            while not self._stop_mc.is_set():
                data, _ = s.recvfrom(2048)
                try:
                    text = data.decode('utf-8', errors='ignore')
                    if not text.startswith("DNCHELLO "):
                        continue
                    _, ip, p_str, address = text.split(" ", 3)
                    p = int(p_str)
                    if p != port:
                        continue  # different subnet (custom port)
                    # Don't add self
                    if ip == self._get_local_ip() and p == self.listen_port:
                        continue
                    if self.add_peer(ip, p, address.strip()):
                        # reward discovery
                        self.reputation.reward(ip, p, 1)
                        # try peer-exchange
                        try:
                            self._peer_exchange_with(ip, p)
                        except Exception:
                            pass
                except Exception:
                    continue
        except Exception as e:
            print(f"[DNCAdapter] Multicast receiver error: {e}")

    def _peer_exchange_with(self, ip: str, port: int) -> int:
        """Ask a known peer for its peer list, and merge new ones. Returns count merged."""
        merged = 0
        try:
            with socket.create_connection((ip, int(port)), timeout=2.5) as s:
                s.sendall(b"getpeerlist")
                buf = s.recv(1_000_000)
                if not buf:
                    return 0
                their_list = json.loads(buf.decode("utf-8"))
                for entry in their_list:
                    eip = entry.get("ip"); eport = entry.get("port"); eaddr = entry.get("address", "")
                    if eip and eport:
                        if self.add_peer(eip, int(eport), eaddr):
                            merged += 1
        except Exception:
            return merged
        return merged

    def ping_peers_real(self, peers):
        """Return how many peers are alive via real TCP ping."""
        alive = 0
        for peer in peers:
            try:
                ip = peer.get("ip")
                port = int(peer.get("port")) if peer.get("port") is not None else None
                if not ip or not port:
                    continue
                with socket.create_connection((ip, port), timeout=1.8) as s:
                    s.sendall(b"ping")
                    resp = s.recv(1024)
                    if resp == b"pong":
                        alive += 1
                        peer["last_seen"] = datetime.now().isoformat()
                        # reward liveness
                        self.reputation.reward(ip, port, 1)
            except Exception:
                continue
        return alive

    # ----------------- Hidden identifier -----------------
    def _ensure_hidden_id(self):
        """Create a hidden identifier bound to our public key and selected port."""
        if self._hidden_id or not self.dnc or self.listen_port is None:
            return
        import hashlib
        pk = self.dnc.get_public_key() or ""
        seed = f"{pk}|{self.listen_port}".encode('utf-8')
        self._hidden_id = hashlib.sha256(seed).hexdigest()[:12]

    def get_hidden_id(self):
        self._ensure_hidden_id()
        return self._hidden_id or ""

    # ----------------- Session / account -----------------
    def create_new_account(self):
        try:
            self.dnc = DNCAuxiliary(mode="new")
            self._ensure_hidden_id()
            return True
        except Exception as e:
            print(f"Error creating account: {e}")
            return False
    
    def login_with_keys(self, public_key, private_key):
        try:
            self.dnc = DNCAuxiliary(mode="existing", public_key=public_key, private_key=private_key)
            self._ensure_hidden_id()
            return True
        except Exception as e:
            print(f"Error logging in: {e}")
            return False
    
    def logout(self):
        if self.mining_active:
            self.stop_mining()
        self.dnc = None
    
    # ----------------- Keys -----------------
    def get_address(self):
        if not self.dnc:
            return ""
        return self.dnc.get_address()
    
    def get_public_key(self):
        if not self.dnc:
            return ""
        return self.dnc.get_public_key()
    
    def get_private_key(self):
        if not self.dnc:
            return ""
        return self.dnc.get_private_key()
    
    def get_keys_info(self):
        if not self.dnc:
            return {"address": "", "public_key": "", "private_key": ""}
        return {
            "address": self.dnc.get_address(),
            "public_key": self.dnc.get_public_key(),
            "private_key": self.dnc.get_private_key()
        }
    
    # ----------------- Wallet -----------------
    def get_balance(self):
        if not self.dnc:
            return 0
        return self.dnc.get_balance()
    
    def send_diac(self, recipient, amount):
        if not self.dnc:
            return False, "No active session"
        try:
            txid = self.dnc.send_transaction(recipient, amount)
            return True, f"Transaction sent. ID: {txid[:8]}..."
        except Exception as e:
            return False, str(e)
    
    # ----------------- Mining -----------------
    def start_mining(self):
        if not self.dnc or self.mining_active:
            return False
        self.mining_active = True
        self.mining_thread = threading.Thread(target=self._mining_worker, daemon=True)
        self.mining_thread.start()
        return True
    
    def stop_mining(self):
        self.mining_active = False
        if self.mining_thread:
            self.mining_thread.join(timeout=1.0)
            self.mining_thread = None
    
    def _mining_worker(self):
        while self.mining_active and self.dnc:
            try:
                self.dnc.perform_mining_cycle()
                time.sleep(2)
            except Exception as e:
                print(f"Mining cycle error: {e}")
                time.sleep(5)
    
    def get_mining_stats(self):
        if not self.dnc:
            return {
                "total_rewards": 0,
                "hourly_rate": 0,
                "completed_challenges": 0,
                "efficiency": 0
            }
        return self.dnc.get_mining_stats()
    
    # ----------------- Network -----------------
    def get_network_stats(self):
        """Real stats: counts only peers that respond to TCP ping."""
        if not self.dnc:
            return {"connected_peers": 0, "synced_fragments": 0, "mvs_synced": False}
        peers = self.dnc.get_peers_list()
        active = self.ping_peers_real(peers)
        return {"connected_peers": active, "synced_fragments": 0, "mvs_synced": False}
    
    def get_recent_transactions(self):
        if not self.dnc:
            return []
        return self.dnc.get_recent_transactions()
    
    def get_peers(self):
        if not self.dnc:
            return []
        return self.dnc.get_peers_list()

    def add_peer(self, ip: str, port: int, address: str = ""):
        """Add a peer (IP/port[/address]) via core."""
        if not self.dnc:
            return False
        try:
            added = self.dnc.add_peer(ip=ip, port=int(port), address=address)
            return added
        except Exception as e:
            print(f"Error adding peer: {e}")
            return False
    
    def discover_peers(self):
        """Peer discovery without URL: for each known peer, request peerlist and merge.
           Returns total number of newly merged peers.
        """
        if not self.dnc:
            return 0
        merged_total = 0
        for peer in list(self.get_peers() or []):
            ip = peer.get("ip")
            port = peer.get("port")
            if not ip or not port: 
                continue
            try:
                merged_total += self._peer_exchange_with(ip, int(port))
            except Exception:
                continue
        return merged_total

    # ----------------- GUI helper API (Reputation / Guardians / PoS) -----------------
    # Reputation
    def get_reputation_snapshot(self):
        return self.reputation.snapshot()

    def reward_peer(self, ip: str, port: int, amount: int = 1):
        self.reputation.reward(ip, int(port), amount)

    def slash_peer(self, ip: str, port: int, amount: int = 10):
        self.reputation.slash(ip, int(port), amount)

    # PoS (local self-demo)
    def load_pos_fragment_from_file(self, filepath: str):
        try:
            with open(filepath, "rb") as f:
                data = f.read()
            self._fragment_data = data
            return True, f"Loaded fragment: {len(data)} bytes"
        except Exception as e:
            return False, str(e)

    def self_pos_challenge_and_verify(self):
        """Generate a PoS challenge against our own stored fragment and verify locally (demo)."""
        if not self._fragment_data:
            return False, "No fragment loaded"
        try:
            frag = self._fragment_data
            # pick an index within fragment length
            max_idx = max(1, len(frag) // CHUNK_SIZE)
            # simple deterministic index for demo: use seconds so UI changes
            idx = int(time.time()) % max_idx
            salt = bytes((idx % 251 for _ in range(16)))
            start = idx * CHUNK_SIZE
            end = min(start + CHUNK_SIZE, len(frag))
            chunk = frag[start:end]
            resp = expected_response(frag, idx, chunk, salt)
            ok = verify_response(frag, idx, salt, resp, chunk)
            return True, {"idx": idx, "ok": bool(ok), "chunk_len": len(chunk)}
        except Exception as e:
            return False, str(e)
