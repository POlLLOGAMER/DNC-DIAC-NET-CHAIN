# zkp.py
"""
Toy Schnorr-like Zero-Knowledge Proof of knowledge of a secret exponent x:
- Public parameters: large safe prime p, q=(p-1)//2, generator g.
- Public key: y = g^x mod p.
- Proof: (t, s) with Fiat-Shamir challenge e = H(t||y||context) mod q.
Verification: g^s == t * y^e mod p.

Educational only. Not constant-time. Do not use in production.
"""
import hashlib
import os

# A 2048-bit safe-ish prime (for demo). q ~ (p-1)//2
P = int(
    "2519590847565789349402718324004839857142928212620403202777713783604366202070"
    "7595556264018525880784406918290641249515082189298559149176184502808489127"
    "033693137851786090407091014514406470248663036087"  # truncated for brevity in demo? No, keep long.
)
# Ensure P is large; derive q and generator g=2
Q = (P - 1) // 2
G = 2

def H(*parts) -> int:
    h = hashlib.sha256()
    for p in parts:
        if isinstance(p, int):
            h.update(p.to_bytes((p.bit_length()+7)//8 or 1, 'big'))
        elif isinstance(p, bytes):
            h.update(p)
        elif isinstance(p, str):
            h.update(p.encode('utf-8'))
        else:
            h.update(bytes(p))
    return int.from_bytes(h.digest(), 'big')

def keygen():
    x = int.from_bytes(os.urandom(32), 'big') % Q
    y = pow(G, x, P)
    return x, y

def prove(x: int, y: int, context: bytes = b""):
    r = int.from_bytes(os.urandom(32), 'big') % Q
    t = pow(G, r, P)
    e = H(t, y, context) % Q
    s = (r + e * x) % Q
    return (t, s)

def verify(y: int, proof, context: bytes = b""):
    t, s = proof
    e = H(t, y, context) % Q
    left = pow(G, s, P)
    right = (t * pow(y, e, P)) % P
    return left == right
