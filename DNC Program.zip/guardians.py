"""
Key Guardians (2-of-3) with HMAC-based approvals (educational).
- Register up to 3 guardians (ids + shared HMAC secrets).
- Propose recovery to a new public key; require 2 valid HMAC approvals.
Persistence: ~/.diac_dnc/guardians.json
"""
import json
import hmac
import hashlib
from pathlib import Path
from typing import List, Dict

class Guardians:
    def __init__(self, base_path: Path):
        self.file = base_path / "guardians.json"
        self.state = {"guardians": []}  # list of {id, secret_hex}
        self._load()

    def _load(self):
        if self.file.exists():
            try:
                self.state = json.loads(self.file.read_text(encoding="utf-8"))
            except Exception:
                self.state = {"guardians": []}
        else:
            self._save()

    def _save(self):
        try:
            self.file.write_text(json.dumps(self.state, indent=2), encoding="utf-8")
        except Exception:
            pass

    def list_guardians(self) -> List[Dict]:
        return list(self.state.get("guardians", []))

    def register_guardians(self, items: List[Dict[str, str]]):
        """
        items: list of {"id": "...", "secret_hex": "..."}
        """
        if not (1 <= len(items) <= 3):
            raise ValueError("Register between 1 and 3 guardians")
        self.state["guardians"] = items
        self._save()

    def _mac(self, secret_hex: str, msg: bytes) -> str:
        key = bytes.fromhex(secret_hex)
        return hmac.new(key, msg, hashlib.sha256).hexdigest()

    def approve_recovery(self, guardian_id: str, secret_hex: str, new_public_key: str) -> str:
        msg = f"RECOVER:{new_public_key}".encode("utf-8")
        return self._mac(secret_hex, msg)

    def verify_recovery(self, approvals: List[Dict[str, str]], new_public_key: str) -> bool:
        """
        approvals: list of {"id": "...", "mac": "hex"}
        Need at least 2 valid MACs from registered guardians.
        """
        registered = {g["id"]: g["secret_hex"] for g in self.list_guardians()}
        if len(registered) == 0:
            return False
        valid = 0
        msg = f"RECOVER:{new_public_key}".encode("utf-8")
        for ap in approvals:
            gid = ap.get("id"); mac = ap.get("mac")
            sech = registered.get(gid)
            if not sech: 
                continue
            expect = self._mac(sech, msg)
            if hmac.compare_digest(expect, mac or ""):
                valid += 1
        return valid >= 2