# shamir.py
"""
Shamir Secret Sharing over a large prime field (toy, educational).
- split_secret(secret_bytes, k, n) -> list of (i, share_bytes)
- combine_shares(shares) -> secret_bytes

Assumptions:
- secret_bytes length <= 64 bytes. Internally mapped to an integer < P.
- P is a fixed 521-bit prime (2**521 - 1 is not prime; we use a known large prime below).
This is NOT production-grade; it's for demos and education.
"""
import os
import random

# A 521-bit prime (chosen to be > 2**520). For demo purposes.
P = int(
    "686479766013060971498190079908139321726943530014330540939446345918554318339"
    "765605212255964066145455497729631139148085803712198799971664381257402829111"
    "5057151"
)

def _bytes_to_int(b: bytes) -> int:
    return int.from_bytes(b, 'big')

def _int_to_bytes(x: int, length: int) -> bytes:
    return x.to_bytes(length, 'big')

def split_secret(secret: bytes, k: int, n: int):
    if not (1 < k <= n <= 255):
        raise ValueError("Requires 1 < k <= n <= 255")
    if len(secret) == 0 or len(secret) > 64:
        raise ValueError("Secret length must be 1..64 bytes")
    s = _bytes_to_int(secret)
    if s >= P:
        raise ValueError("Secret too large for field")
    # Random polynomial: f(x) = a0 + a1 x + ... + a_{k-1} x^{k-1} mod P
    coeffs = [s] + [random.randrange(1, P) for _ in range(k-1)]
    shares = []
    for x in range(1, n+1):
        y = 0
        xp = 1
        for a in coeffs:
            y = (y + a * xp) % P
            xp = (xp * x) % P
        # encode share: (x, y) with y into fixed size
        share_len = (P.bit_length() + 7)//8
        shares.append( (x, _int_to_bytes(y, share_len)) )
    return shares

def _lagrange_interpolate(x_vals, y_vals, x=0, p=P):
    """Interpolate at x=0 using given points (x_i, y_i) over F_p."""
    k = len(x_vals)
    total = 0
    for i in range(k):
        xi, yi = x_vals[i], y_vals[i]
        num = 1
        den = 1
        for j in range(k):
            if i == j: continue
            xj = x_vals[j]
            num = (num * (x - xj)) % p
            den = (den * (xi - xj)) % p
        inv = pow(den, -1, p)
        li = (num * inv) % p
        total = (total + yi * li) % p
    return total

def combine_shares(shares):
    """
    shares: list of (x, share_bytes). Need at least k distinct x.
    """
    if len(shares) < 2:
        raise ValueError("Need at least 2 shares")
    x_vals = []
    y_vals = []
    for (x, yb) in shares:
        y = int.from_bytes(yb, 'big')
        x_vals.append(int(x))
        y_vals.append(y)
    s = _lagrange_interpolate(x_vals, y_vals, x=0, p=P)
    # Secret bytes length is ambiguous; callers should know original length.
    # We return minimal-length bytes (no leading zeros).
    blen = (s.bit_length() + 7)//8 or 1
    return s.to_bytes(blen, 'big')
