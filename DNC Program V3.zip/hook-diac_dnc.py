# hook-diac_dnc.py
from PyInstaller.utils.hooks import collect_submodules
hiddenimports = collect_submodules('diac_dnc')
