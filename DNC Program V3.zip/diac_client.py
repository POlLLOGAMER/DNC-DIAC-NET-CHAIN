#!/usr/bin/env python3
"""
diac_client.py — Lanzador del cliente DIAC DNC

Requisitos de estructura (paquete):
project_root/
  diac_client.py
  diac_dnc/
    __init__.py
    diac_dnc_gui.py
    diac_dnc_adapter.py

Importa SIEMPRE desde el paquete para que funcione en ejecutables congelados (PyInstaller).
"""

import tkinter as tk
from diac_dnc.diac_dnc_gui import DNCClientGUI


def main() -> None:
    root = tk.Tk()
    app = DNCClientGUI(root)  # type: ignore
    root.mainloop()


if __name__ == "__main__":
    main()
