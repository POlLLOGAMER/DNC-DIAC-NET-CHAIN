
# pos_proof.py - Proof of Storage with remote challenge/response
# Stores a local "fragment file" (any file path). Peers can challenge for a random chunk.
# Response returns {idx, chunk_sha256}. Verifier compares with its own expected hash (if known)
# or accepts first-seen & caches; repeat mismatches trigger slashing.
import os, hashlib, json
from pathlib import Path

class PoSStore:
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.cfg = base_path / "pos_config.json"
        self.state = {"fragment_path": "", "last_result": {}}
        self._load()

    def _load(self):
        if self.cfg.exists():
            try:
                self.state = json.loads(self.cfg.read_text(encoding="utf-8"))
            except Exception:
                pass
        else:
            self._save()

    def _save(self):
        try:
            self.cfg.write_text(json.dumps(self.state, indent=2), encoding="utf-8")
        except Exception:
            pass

    def set_fragment(self, path: str):
        self.state["fragment_path"] = path
        self._save()

    def get_fragment_path(self) -> str:
        return self.state.get("fragment_path","")

    def _read_chunk(self, path: str, idx: int, chunk_size: int = 32768) -> bytes:
        if not os.path.exists(path):
            raise FileNotFoundError("Fragment not found")
        size = os.path.getsize(path)
        if size == 0:
            raise ValueError("Empty fragment")
        # wrap-around index to chunks
        total_chunks = max(1, (size + chunk_size - 1) // chunk_size)
        idx = idx % total_chunks
        with open(path, "rb") as f:
            f.seek(idx * chunk_size)
            return f.read(chunk_size)

    def challenge_local(self, idx: int) -> dict:
        """Self-challenge: return dict with idx, sha256hex, chunk_len"""
        path = self.get_fragment_path()
        if not path:
            return {"ok": False, "error": "no_fragment"}
        try:
            chunk = self._read_chunk(path, idx)
            sha = hashlib.sha256(chunk).hexdigest()
            res = {"ok": True, "idx": int(idx), "sha256": sha, "chunk_len": len(chunk)}
            self.state["last_result"] = res
            self._save()
            return res
        except Exception as e:
            return {"ok": False, "error": str(e)}
