"""
diac_infinity2.py
==================

This module contains a reference implementation of the DIAC ∞ 2 hybrid
encryption system as described in the accompanying white‑paper.  It
implements a hybrid public key encryption scheme based on a post‑quantum
KEM (Kyber/ML‑KEM‑512), a transcendental window pseudorandom function
that produces an effectively unbounded key search space, and a
dual‑encryption mechanism consisting of ChaCha20‑Poly1305 and a custom
post‑quantum AEAD.  The goal of including this file in the DNC 2
repository is to expose the key generation, encryption and decryption
primitives required to integrate DIAC ∞ 2 into higher‑level
applications, such as the DIAC Net Chain GUI.

**Caveats**

* This reference requires the `pqcrypto` and `pycryptodome` packages
  to be installed in the runtime environment.  When running outside
  the controlled environment in this repository these may need to be
  installed manually (e.g. with `pip install pqcrypto pycryptodome`).
* The code in this module has been transcribed from the original
  white‑paper and may not have been thoroughly tested in this
  environment.  It is provided as a starting point for further
  development and integration.
"""

import os
import json
import base64
import struct
import hmac
import hashlib
import secrets
import math
from typing import Tuple, Dict

# Third‑party cryptographic primitives.  These imports will raise
# ImportError if the dependencies are not available; callers should
# handle that gracefully or instruct users to install the required
# packages.
from Crypto.Cipher import ChaCha20_Poly1305  # type: ignore
from pqcrypto.kem import ml_kem_512 as mlkem  # type: ignore

VERSION: int = 2

# Limits for the BBP (Bailey–Borwein–Plouffe) exact π digit extractor.
BBP_MAX_OFFSET: int = 100_000  # maximum hex‑digit index for BBP exact
BBP_MAX_P_BYTES: int = 64      # maximum bytes extracted with BBP
DEFAULT_P_BYTES: int = 64      # default number of bytes extracted


# === Utility functions ===

def sha256(data: bytes) -> bytes:
    """Return the SHA‑256 digest of *data* as raw bytes."""
    return hashlib.sha256(data).digest()


def sha512(data: bytes) -> bytes:
    """Return the SHA‑512 digest of *data* as raw bytes."""
    return hashlib.sha512(data).digest()


def hkdf_sha512(ikm: bytes, salt: bytes, info: bytes, length: int) -> bytes:
    """A simple HKDF based on HMAC‑SHA512.

    Args:
        ikm: initial keying material.
        salt: salt value (may be empty).
        info: context and application specific information.
        length: number of bytes to derive.

    Returns:
        A byte string of length *length* containing key material.
    """
    # Extract
    prk = hmac.new(salt, ikm, hashlib.sha512).digest()
    okm = b""
    t = b""
    c = 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([c]), hashlib.sha512).digest()
        okm += t
        c += 1
    return okm[:length]


# === Transcendental Window pseudorandom generator ===

# Pre‑seed values derived from constant names.  The seeds are the
# SHA‑256 digest of the ASCII name of the constant.  These seeds are
# kept constant and public; only the offset O and byte count P vary.
_SEEDMAP: Dict[str, bytes] = {
    "pi": sha256(b"pi"),
    "e": sha256(b"e"),
    "sqrt2": sha256(b"sqrt2"),
}


def tw_fast_bytes(base: str, O: int, P_bytes: int) -> bytes:
    """Produce *P_bytes* of pseudorandom output using FAST mode.

    FAST mode uses HKDF to expand a fixed seed with a salt derived
    from the chosen base, offset *O* and number of bytes.  It is
    computationally cheap and suitable for real‑time use.  The caller
    must ensure that *O* lies in the range [1, 2⁶⁴‑1].
    """
    if base not in _SEEDMAP:
        raise ValueError(f"Invalid base: {base}")
    if not (1 <= O <= (1 << 64) - 1):
        raise ValueError("O must be in [1, 2^64 – 1]")
    seed = _SEEDMAP[base]
    # Salt is SHA‑512 of (base || O || P_bytes)
    salt = sha512(base.encode() + O.to_bytes(8, "big") + P_bytes.to_bytes(4, "big"))
    return hkdf_sha512(seed, salt, b"DIAC2-TW-FAST", P_bytes)


def _series(j: int, n: int) -> float:
    """Helper function for the BBP π digit extraction.

    Computes the infinite sum in a way that converges quickly.
    """
    s = 0.0
    # First sum up to n
    for k in range(n + 1):
        denom = 8 * k + j
        s += pow(16, n - k, denom) / denom
        s -= math.floor(s)
    # Then sum the tail until small enough
    k = n + 1
    term = 1.0
    while term > 1e-17:
        term = (16.0 ** (n - k)) / (8 * k + j)
        s += term
        s -= math.floor(s)
        k += 1
    return s % 1.0


def _pi_hex_digit(n: int) -> int:
    """Return the n‑th hexadecimal digit of π (1‑indexed)."""
    n -= 1
    x = (
        4.0 * _series(1, n)
        - 2.0 * _series(4, n)
        - _series(5, n)
        - _series(6, n)
    ) % 1.0
    return int(16.0 * x)


def tw_bbp_bytes_pi(O_hex: int, P_bytes: int) -> bytes:
    """Extract *P_bytes* from π in hex using the BBP formula.

    *O_hex* is the hex‑digit offset (1‑indexed).  This function
    constrains *O_hex* and *P_bytes* to safe limits to avoid long
    runtimes.
    """
    if O_hex < 1:
        raise ValueError("For BBP, O must be >= 1 (hex‑digit index).")
    if O_hex > BBP_MAX_OFFSET:
        raise ValueError(
            f"For BBP, O too large.  Choose O <= {BBP_MAX_OFFSET} or use FAST mode."
        )
    if P_bytes < 1 or P_bytes > BBP_MAX_P_BYTES:
        raise ValueError(
            f"For BBP, P must be in [1, {BBP_MAX_P_BYTES}]."
        )
    hex_len = P_bytes * 2
    hex_digits = "".join(
        "0123456789abcdef"[_pi_hex_digit(O_hex + i)] for i in range(hex_len)
    )
    return bytes.fromhex(hex_digits)


# === PQ‑AEAD layer ===

def _kdf_pq_aead(master: bytes, salt: bytes) -> Tuple[bytes, bytes]:
    """Derive encryption and MAC keys for the PQ‑AEAD layer."""
    kenc = hkdf_sha512(master, salt, b"pq/kenc", 32)
    kmac = hkdf_sha512(master, salt, b"pq/kmac", 32)
    return kenc, kmac


def _shake_stream(kenc: bytes, nonce: bytes, aad: bytes, length: int) -> bytes:
    """Produce a keystream using SHAKE‑256 keyed by *kenc* and contextual data."""
    shake = hashlib.shake_256()
    shake.update(b"DIAC2-PQ-AEAD|ENC|")
    shake.update(len(kenc).to_bytes(2, "big") + kenc)
    shake.update(len(nonce).to_bytes(2, "big") + nonce)
    shake.update(len(aad).to_bytes(4, "big") + aad)
    return shake.digest(length)


def _hmac_sha3_256(key: bytes, data: bytes) -> bytes:
    """Compute HMAC‑SHA3‑256 over *data* with *key*."""
    return hmac.new(key, data, digestmod=hashlib.sha3_256).digest()


def pq_aead_encrypt(plaintext: bytes, master: bytes, salt: bytes, aad: bytes = b"") -> bytes:
    """Encrypt a message using the custom PQ‑AEAD scheme.

    Returns: nonce || tag || ciphertext
    """
    nonce = os.urandom(12)
    kenc, kmac = _kdf_pq_aead(master, salt + nonce)
    ks = _shake_stream(kenc, nonce, aad, len(plaintext))
    ct = bytes(a ^ b for a, b in zip(plaintext, ks))
    tag = _hmac_sha3_256(kmac, b"DIAC2-PQ-AEAD|MAC|" + nonce + aad + ct)
    return nonce + tag + ct


def pq_aead_decrypt(blob: bytes, master: bytes, salt: bytes, aad: bytes = b"") -> bytes:
    """Decrypt a message produced by ``pq_aead_encrypt``.

    Raises ValueError if authentication fails or the input is malformed.
    """
    if len(blob) < 44:
        raise ValueError("Invalid ciphertext length")
    nonce, tag, ct = blob[:12], blob[12:44], blob[44:]
    kenc, kmac = _kdf_pq_aead(master, salt + nonce)
    expect = _hmac_sha3_256(kmac, b"DIAC2-PQ-AEAD|MAC|" + nonce + aad + ct)
    if not hmac.compare_digest(tag, expect):
        raise ValueError("PQ‑AEAD authentication failed")
    ks = _shake_stream(kenc, nonce, aad, len(ct))
    return bytes(a ^ b for a, b in zip(ct, ks))


# === KDF for K1/K2 using the Transcendental Window as secret ===

def _derive_k1_k2_with_tw(ss: bytes, TW: bytes) -> Tuple[bytes, bytes]:
    """Derive the two symmetric keys K1 and K2 from the shared secret and TW."""
    # K_base = HKDF(ss || TW, salt = b"", info = b"DIAC∞", length = 64)
    info = b"DIAC\xe2\x88\x9e"  # 'DIAC∞' encoded in UTF‑8
    K_base = hkdf_sha512(ss + TW, b"", info, 64)
    return K_base[:32], K_base[32:]


# === Key and value (TW) helper functions ===

def tw_bytes(mode: str, base: str, O: int, P_bytes: int) -> bytes:
    """Compute the Transcendental Window output according to the selected mode."""
    mode_u = (mode or "").strip().upper()
    if mode_u == "FAST":
        return tw_fast_bytes(base, O, P_bytes)
    if mode_u == "BBP":
        if base != "pi":
            raise ValueError("BBP exact mode only supports base='pi'")
        return tw_bbp_bytes_pi(O, P_bytes)
    raise ValueError(f"Invalid TW mode: {mode}")


def pack_public(pk: bytes, hN: bytes, mode: str, base: str, P_bytes: int) -> str:
    """Serialize public key data into a JSON string."""
    obj = {
        "alg": "ML-KEM-512",
        "pk": base64.b64encode(pk).decode(),
        "hN": hN.hex(),
        "mode": mode,
        "base": base,
        "P": P_bytes,
        "ver": VERSION,
    }
    return json.dumps(obj, separators=(",", ":"))


def pack_private(sk: bytes, mode: str, base: str, O: int, P_bytes: int) -> str:
    """Serialize private key data into a JSON string."""
    obj = {
        "alg": "ML-KEM-512",
        "sk": base64.b64encode(sk).decode(),
        "mode": mode,
        "base": base,
        "O": int(O),
        "P": int(P_bytes),
        "ver": VERSION,
    }
    return json.dumps(obj, separators=(",", ":"))


def keygen(
    mode: str = "FAST",
    base: str = "pi",
    O: int | None = None,
    P_bytes: int = DEFAULT_P_BYTES,
    O_max: int = (1 << 32) - 1,
) -> Tuple[str, str]:
    """Generate a DIAC ∞ 2 key pair and return (public_json, private_json)."""
    if O is None:
        # Random offset in [1, O_max]
        O = secrets.randbelow(O_max) + 1
    tw = tw_bytes(mode, base, O, P_bytes)
    hN = sha256(tw)
    pk, sk = mlkem.generate_keypair()
    return pack_public(pk, hN, mode, base, P_bytes), pack_private(sk, mode, base, O, P_bytes)


def encrypt(pub_json: str, message: str, TW: bytes | str | None = None, O: int | None = None) -> str:
    """Encrypt a UTF‑8 message using the provided serialized public key.

    Either the raw TW bytes or the offset *O* must be supplied so that
    K1 and K2 can be derived correctly.
    """
    pub = json.loads(pub_json)
    if pub.get("alg") != "ML-KEM-512":
        raise ValueError("Unsupported algorithm")
    # Recover TW either directly or via O
    if TW is None:
        if O is None:
            raise ValueError("encrypt() requires TW or O to derive K1/K2")
        TW_bytes = tw_bytes(pub["mode"], pub["base"], int(O), int(pub["P"]))
    else:
        TW_bytes = TW.encode("utf-8") if isinstance(TW, str) else TW
    pk = base64.b64decode(pub["pk"])
    hN = bytes.fromhex(pub["hN"])
    aad1 = b"layer1|" + hN
    aad2 = b"layer2|" + hN
    ct_kem, ss = mlkem.encrypt(pk)
    K1, K2 = _derive_k1_k2_with_tw(ss, TW_bytes)
    cipher1 = ChaCha20_Poly1305.new(key=K1)
    cipher1.update(aad1)
    ct1, tag1 = cipher1.encrypt_and_digest(message.encode())
    layer1 = cipher1.nonce + tag1 + ct1
    blob = pq_aead_encrypt(layer1, master=K2, salt=hN, aad=aad2)
    out = bytes([VERSION]) + struct.pack(">H", len(ct_kem)) + ct_kem + blob
    return base64.b64encode(out).decode()


def decrypt(priv_json: str, ciphertext_b64: str) -> str:
    """Decrypt a base64 encoded ciphertext using the serialized private key."""
    priv = json.loads(priv_json)
    if priv.get("alg") != "ML-KEM-512":
        raise ValueError("Unsupported algorithm")
    mode = priv["mode"]
    base = priv["base"]
    O = int(priv["O"])
    P_bytes = int(priv["P"])
    raw = base64.b64decode(ciphertext_b64)
    if len(raw) < 3:
        raise ValueError("Invalid ciphertext")
    ver = raw[0]
    if ver != VERSION:
        raise ValueError("Unsupported version")
    L = struct.unpack(">H", raw[1:3])[0]
    if len(raw) < 3 + L:
        raise ValueError("Invalid ciphertext length")
    ct_kem = raw[3 : 3 + L]
    blob = raw[3 + L :]
    sk = base64.b64decode(priv["sk"])
    ss = mlkem.decrypt(sk, ct_kem)
    tw = tw_bytes(mode, base, O, P_bytes)
    hN = sha256(tw)
    aad1 = b"layer1|" + hN
    aad2 = b"layer2|" + hN
    K1, K2 = _derive_k1_k2_with_tw(ss, tw)
    layer1 = pq_aead_decrypt(blob, master=K2, salt=hN, aad=aad2)
    if len(layer1) < 28:
        raise ValueError("Invalid inner ciphertext length")
    nonce1, tag1, ct1 = layer1[:12], layer1[12:28], layer1[28:]
    cipher1 = ChaCha20_Poly1305.new(key=K1, nonce=nonce1)
    cipher1.update(aad1)
    pt = cipher1.decrypt_and_verify(ct1, tag1)
    return pt.decode()
