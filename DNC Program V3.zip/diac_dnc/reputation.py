
# reputation.py - Reputation, slashing log and snapshot
import json, time, hashlib
from pathlib import Path

class Reputation:
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.file = base_path / "reputation.json"
        self.slash_log = base_path / "slashing_log.json"
        self._load()

    def _load(self):
        if self.file.exists():
            try:
                self.state = json.loads(self.file.read_text(encoding="utf-8"))
            except Exception:
                self.state = {}
        else:
            self.state = {}
            self._save()
        if not self.slash_log.exists():
            self._save_slash({"events": []})

    def _save(self):
        try:
            self.file.write_text(json.dumps(self.state, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _save_slash(self, data):
        try:
            self.slash_log.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass

    def get(self, ip, port) -> int:
        return int(self.state.get(f"{ip}:{port}", 0))

    def set(self, ip, port, score: int):
        self.state[f"{ip}:{port}"] = int(score)
        self._save()

    def reward(self, ip, port, points=1):
        s = self.get(ip, port) + int(points)
        self.set(ip, port, s)
        return s

    def slash(self, ip, port, points=5, reason="generic"):
        s = self.get(ip, port) - int(points)
        self.set(ip, port, s)
        self._append_slash(ip, port, reason, reporter="local")
        return s

    def snapshot(self):
        return dict(self.state)

    def _append_slash(self, ip, port, reason, reporter="local"):
        ev = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "peer": f"{ip}:{port}",
            "reason": reason,
            "reporter": reporter,
        }
        try:
            data = json.loads(self.slash_log.read_text(encoding="utf-8"))
        except Exception:
            data = {"events": []}
        # assign id
        ev_str = f"{ev['ts']}|{ev['peer']}|{ev['reason']}|{ev['reporter']}"
        ev["id"] = hashlib.sha256(ev_str.encode()).hexdigest()
        data.setdefault("events", []).append(ev)
        self._save_slash(data)
        return ev
