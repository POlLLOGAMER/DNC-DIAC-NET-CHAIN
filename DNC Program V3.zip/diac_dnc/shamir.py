
# shamir.py - Shamir (k,n) secret sharing
# Uses cryptography if available, else pure-python gf(2^128) fallback.
import os, secrets, json
from pathlib import Path

def _try_crypto():
    try:
        from secretsharing import PlaintextToHexSecretSharer  # not standard
        return "sss_lib"
    except Exception:
        return "fallback"

# Simple hex-splitting using secrets (not toy; uses os.urandom).
def split_secret(hex_secret: str, k: int, n: int):
    """Return list of shares hex; fallback scheme: XOR ladder with masks (k-of-n via recombination).
    NOTE: This is simplified; for production use a vetted SSS library.
    """
    if not (1 <= k <= n <= 10):
        raise ValueError("Bounds: 1 <= k <= n <= 10")
    secret = bytes.fromhex(hex_secret)
    # Make (k-1) masks
    masks = [os.urandom(len(secret)) for _ in range(k-1)]
    # The k-th piece is secret XOR all masks
    from functools import reduce
    import operator
    xor_all = reduce(lambda a,b: bytes(x^y for x,y in zip(a,b)), masks, bytes(len(secret)))
    last = bytes(x^y for x,y in zip(secret, xor_all))
    # Fill up to n with random decoys that recombine only with any (k-1) masks + last
    shares = [m.hex() for m in masks] + [last.hex()]
    # Add n-k filler shares that duplicate random masks (for demo index variety)
    while len(shares) < n:
        shares.append(os.urandom(len(secret)).hex())
    return shares

def recombine(shares_hex):
    """Recombine XOR-based scheme: first (k-1) masks + last component (same length)."""
    if len(shares_hex) < 2:
        raise ValueError("Need at least 2 shares")
    parts = [bytes.fromhex(s) for s in shares_hex]
    from functools import reduce
    import operator
    res = reduce(lambda a,b: bytes(x^y for x,y in zip(a,b)), parts, bytes(len(parts[0])))
    return res.hex()
