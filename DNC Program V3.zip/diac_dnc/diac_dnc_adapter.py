import socket
import threading
import json
import time
import hashlib
import base64
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

# ----------------------------------------------------------------------
# Reputation (optional external module). If it's missing, use a stub.
# ----------------------------------------------------------------------
try:
    from reputation import Reputation  # type: ignore
except Exception:
    class Reputation:  # minimal fallback so the GUI doesn't break
        def __init__(self, base_path: Optional[Path] = None) -> None:
            self._scores: Dict[str, int] = {}
        def add(self, key: str, points: int) -> None:
            self._scores[key] = self._scores.get(key, 0) + int(points)
        def snapshot(self) -> Dict[str, int]:
            return dict(self._scores)

# Default “central” port for the GUI
DEFAULT_DIAC_PORT = 369


def _sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


class DNCAdapter:
    """
    Adapter between the GUI and the core (DNCAuxiliary), providing:
      - Simple TCP JSON server for P2P ops
      - Peer discovery/exchange via RPC
      - Basic Majority-Value Synchronization (MVS)
      - Local reputation (for the GUI)
      - Wrappers to core functions (account, tx, mining, PoS demo)
    """
    def __init__(self):
        # Core (assigned by the GUI when creating/logging in)
        self.dnc = None  # type: DNCAuxiliary

        # Network
        self.listen_port: int = 0
        self._server_thread: Optional[threading.Thread] = None
        self._stop_server = threading.Event()

        # Reputation (local)
        data_dir = Path.home() / '.diac_dnc'
        data_dir.mkdir(parents=True, exist_ok=True)
        try:
            self.reputation = Reputation(base_path=data_dir)  # type: ignore[arg-type]
        except TypeError:
            try:
                self.reputation = Reputation()  # type: ignore[call-arg]
            except TypeError:
                self.reputation = Reputation(base_path=(data_dir / 'reputation.json'))  # type: ignore[arg-type]

        # Simple logfile so the GUI can show precise errors
        self.last_error: str = ""
        self._log_path = data_dir / "app.log"

        # MVS state
        self._mvs_synced: bool = False
        self._last_mvs_time: float = 0.0

        # Mining (wrapper)
        self._mining_thread: Optional[threading.Thread] = None
        self._mining_stop = threading.Event()

        # PoS (local demo)
        self._pos_fragment_path: Optional[Path] = None
        self._pos_fragment_cache: Optional[bytes] = None

    # -------- small helper -------------------------------------------------
    def _log(self, msg: str) -> None:
        try:
            ts = datetime.now().isoformat(timespec="seconds")
            with self._log_path.open("a", encoding="utf-8") as f:
                f.write(f"[{ts}] {msg}\n")
        except Exception:
            pass

    # ====================== Network configuration / server ======================

    def configure_network(self, port: int) -> None:
        """Start the simple TCP server at `port`."""
        if self._server_thread and self._server_thread.is_alive():
            # stop previous server if port changed
            self._stop_server.set()
            try:
                socket.create_connection(("127.0.0.1", self.listen_port), timeout=0.5).close()
            except Exception:
                pass
            self._server_thread.join(timeout=2.0)

        self.listen_port = int(port)
        self._stop_server.clear()
        self._server_thread = threading.Thread(target=self._server_loop, daemon=True)
        self._server_thread.start()
        print(f"[DNCAdapter] Server on port {self.listen_port}")

    def _server_loop(self) -> None:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("", self.listen_port))
            s.listen(64)
            s.settimeout(0.5)
            while not self._stop_server.is_set():
                try:
                    conn, addr = s.accept()
                except socket.timeout:
                    continue
                threading.Thread(target=self._handle_conn, args=(conn, addr), daemon=True).start()
        finally:
            try:
                s.close()
            except Exception:
                pass

    def _handle_conn(self, conn: socket.socket, addr: Tuple[str, int]) -> None:
        data = b""
        conn.settimeout(5.0)
        try:
            while True:
                chunk = conn.recv(65536)
                if not chunk:
                    break
                data += chunk
                if len(chunk) < 65536:
                    break
            if not data:
                return
            req = json.loads(data.decode("utf-8", errors="ignore"))
            op = str(req.get("op", "")).strip()
        except Exception:
            try:
                conn.sendall(json.dumps({"ok": False, "error": "bad_request"}).encode("utf-8"))
            except Exception:
                pass
            conn.close()
            return

        # --- RPC dispatcher ---
        try:
            if op == "ping":
                out = {"ok": True, "pong": True, "port": self.listen_port, "time": time.time()}
                conn.sendall(json.dumps(out).encode("utf-8"))
                conn.close()
                return

            elif op == "getpeerlist":
                peers = self.get_peers()
                conn.sendall(json.dumps({"ok": True, "peers": peers}).encode("utf-8"))
                conn.close()
                return

            elif op == "peer_exchange":
                incoming = req.get("peers", [])
                merged = 0
                for p in incoming:
                    try:
                        ip = str(p.get("ip", "")).strip()
                        port = int(p.get("port", 0))
                        addr_str = str(p.get("address", "")).strip()
                        if ip and port:
                            if self.add_peer(ip, port, addr_str):
                                merged += 1
                    except Exception:
                        continue
                mine = self.get_peers()
                conn.sendall(json.dumps({"ok": True, "merged": merged, "peers": mine}).encode("utf-8"))
                conn.close()
                return

            elif op == "get_synopsis":
                syn = self._get_synopsis()
                conn.sendall(json.dumps({"ok": True, "synopsis": syn}).encode("utf-8"))
                conn.close()
                return

            elif op == "fragment_request":
                frag = self._get_fragment_snapshot()
                conn.sendall(json.dumps({"ok": True, "fragment": frag}).encode("utf-8"))
                conn.close()
                return

            # --- PoS fragment RPCs ---
            elif op == "pos_info":
                has = bool(self._pos_fragment_cache) and len(self._pos_fragment_cache) > 0
                size = len(self._pos_fragment_cache) if self._pos_fragment_cache else 0
                out = {"ok": True, "has_fragment": has, "size": int(size), "chunk_max": 32768}
                conn.sendall(json.dumps(out).encode("utf-8"))
                conn.close()
                return

            elif op == "pos_read_slice":
                idx = int(req.get("idx", 0))
                length = int(req.get("length", 32768))
                chunk = self._pos_read_slice(idx, length)
                h = hashlib.sha256(chunk).hexdigest()
                out = {
                    "ok": True,
                    "idx": idx,
                    "length": len(chunk),
                    "hash": h,
                    "data_b64": base64.b64encode(chunk).decode("ascii"),
                }
                conn.sendall(json.dumps(out).encode("utf-8"))
                conn.close()
                return

            else:
                conn.sendall(json.dumps({"ok": False, "error": "unknown_op"}).encode("utf-8"))
                conn.close()
                return

        except Exception as e:
            try:
                conn.sendall(json.dumps({"ok": False, "error": f"server_err:{e}"}).encode("utf-8"))
            except Exception:
                pass
            conn.close()
            return

    def _request(self, ip: str, port: int, payload: Dict[str, Any], timeout: float = 3.5) -> Optional[Dict[str, Any]]:
        """Perform a JSON request to a peer."""
        try:
            with socket.create_connection((ip, int(port)), timeout=timeout) as c:
                c.sendall(json.dumps(payload).encode("utf-8"))
                c.shutdown(socket.SHUT_WR)
                chunks: List[bytes] = []
                c.settimeout(timeout)
                while True:
                    chunk = c.recv(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    if len(chunk) < 65536:
                        break
            if not chunks:
                return None
            raw = b"".join(chunks)
            return json.loads(raw.decode("utf-8", errors="ignore"))
        except Exception:
            return None

    # =========================== Peer management ============================

    def add_peer(self, ip: str, port: int, address: str = "") -> bool:
        """Add a peer into the core (DNCAuxiliary)."""
        if not self.dnc:
            return False
        try:
            return bool(self.dnc.add_peer(str(ip).strip(), int(port), address))
        except Exception:
            return False

    def get_peers(self) -> List[Dict[str, Any]]:
        """Get the peer list from the core."""
        if not self.dnc:
            return []
        try:
            return list(self.dnc.get_peers_list() or [])
        except Exception:
            return []

    def ping_peers_real(self, peers: List[Dict[str, Any]]) -> int:
        """Ping peers and update last_seen; return number of alive peers."""
        alive = 0
        now = datetime.now().isoformat()
        for p in peers or []:
            ip = p.get("ip")
            port = p.get("port")
            if not ip or not port:
                continue
            r = self._request(ip, int(port), {"op": "ping"})
            if r and r.get("ok"):
                alive += 1
                try:
                    p["last_seen"] = now
                except Exception:
                    pass
        return alive

    def discover_peers(self) -> int:
        """
        Exchange peer lists with known peers.
        Return an approximate count of merged peers.
        """
        peers = self.get_peers()
        total_merged = 0
        mine = peers
        for p in peers:
            ip = p.get("ip")
            port = p.get("port")
            if not ip or not port:
                continue
            resp = self._request(ip, int(port), {"op": "peer_exchange", "peers": mine})
            if resp and resp.get("ok"):
                total_merged += int(resp.get("merged", 0))
                # also merge their list if it brings new peers
                for q in resp.get("peers", []):
                    try:
                        if self.add_peer(q.get("ip"), int(q.get("port")), q.get("address", "")):
                            total_merged += 1
                    except Exception:
                        continue
        return total_merged

    # =============================== MVS ===================================

    def _get_fragment_snapshot(self) -> Dict[str, Any]:
        """Safe copy of the local fragment (balances & transactions)."""
        if not self.dnc:
            return {"balances": {}, "transactions": []}
        try:
            frag = self.dnc.ledger_fragment
            return {
                "balances": dict(frag.get("balances", {})),
                "transactions": list(frag.get("transactions", [])),
            }
        except Exception:
            return {"balances": {}, "transactions": []}

    def _pos_read_slice(self, idx: int, length: int = 32768) -> bytes:
        """
        Return a slice of the currently loaded PoS fragment (local).
        If no fragment is loaded, return empty bytes.
        """
        try:
            if not self._pos_fragment_cache:
                return b""
            data = self._pos_fragment_cache
            if not data:
                return b""
            if length <= 0:
                return b""
            max_len = 32768
            L = min(int(length), max_len, len(data))
            i = max(0, min(int(idx), max(0, len(data) - L)))
            return data[i:i + L]
        except Exception:
            return b""

    def _get_synopsis(self) -> Dict[str, Any]:
        """
        Compute a synopsis: txCount, local balance and a rolling digest of the fragment.
        """
        tx_count = 0
        my_balance = 0.0
        digest = "0" * 64
        if not self.dnc:
            return {"txCount": tx_count, "balance": my_balance, "digest": digest}
        try:
            frag = self.dnc.ledger_fragment
            txs = frag.get("transactions", [])
            tx_count = len(txs)
            my_balance = float(self.dnc.get_balance())
            # digest based on sorted balances + sorted txids
            items: List[str] = []
            for k, v in sorted(frag.get("balances", {}).items()):
                items.append(f"B|{k}|{v}")
            for t in sorted((t.get("txid", "") for t in txs)):
                items.append(f"T|{t}")
            digest = _sha256_hex("\n".join(items).encode("utf-8"))
        except Exception:
            pass
        return {"txCount": tx_count, "balance": my_balance, "digest": digest}

    @staticmethod
    def _mode_value(values: List[Any]) -> Optional[Any]:
        """Simple mode (by equality)."""
        if not values:
            return None
        freq: Dict[Any, int] = {}
        for v in values:
            freq[v] = freq.get(v, 0) + 1
        return max(freq.items(), key=lambda kv: kv[1])[0]

    def update_mvs(self) -> None:
        """
        Collect synopses from peers, compute the per-field mode, and if there is a
        disagreement, attempt to adopt the majority fragment.
        """
        if not self.dnc:
            self._mvs_synced = False
            return

        local = self._get_synopsis()
        synopses: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []  # (peer, syn)
        for p in self.get_peers():
            ip = p.get("ip")
            port = p.get("port")
            if not ip or not port:
                continue
            resp = self._request(ip, int(port), {"op": "get_synopsis"})
            if resp and resp.get("ok"):
                syn = resp.get("synopsis", {})
                synopses.append((p, syn))

        if not synopses:
            self._mvs_synced = False
            return

        tx_counts = [s[1].get("txCount") for s in synopses if isinstance(s[1].get("txCount"), int)]
        balances = [round(float(s[1].get("balance", 0.0)), 8) for s in synopses]
        digests = [s[1].get("digest") for s in synopses if isinstance(s[1].get("digest"), str)]

        mode_tx = self._mode_value(tx_counts)
        mode_bal = self._mode_value(balances)
        mode_dig = self._mode_value(digests)

        disagreement = False
        if mode_tx is not None and local.get("txCount") != mode_tx:
            disagreement = True
        if mode_dig and local.get("digest") != mode_dig:
            disagreement = True
        # Balance differences are allowed; not a strict criterion.

        self._mvs_synced = not disagreement
        self._last_mvs_time = time.time()

        # If there is disagreement, try to adopt the fragment whose digest is the majority
        if disagreement and mode_dig:
            chosen_peer = None
            for p, syn in synopses:
                if syn.get("digest") == mode_dig:
                    chosen_peer = p
                    break
            if chosen_peer:
                frag_resp = self._request(chosen_peer.get("ip"), int(chosen_peer.get("port")), {"op": "fragment_request"})
                if frag_resp and frag_resp.get("ok"):
                    frag = frag_resp.get("fragment", {})
                    try:
                        # Merge/replace with received fragment
                        self.dnc.merge_fragment(frag)
                        local2 = self._get_synopsis()
                        self._mvs_synced = (local2.get("digest") == mode_dig)
                    except Exception:
                        pass

    def get_network_stats(self) -> Dict[str, Any]:
        """Return metrics for the GUI."""
        peers = self.get_peers()
        connected = self.ping_peers_real(peers)
        # Run a quick MVS cycle
        self.update_mvs()
        return {
            "connected_peers": connected,
            "synced_fragments": 0,  # placeholder
            "mvs_synced": bool(self._mvs_synced),
        }

    # =============================== Reputation ==============================

    def get_reputation_snapshot(self) -> Dict[str, int]:
        """Return {'ip:port': score}."""
        try:
            return self.reputation.snapshot()
        except Exception:
            return {}

    def reward_peer(self, ip: str, port: int, points: int = 1) -> bool:
        try:
            key = f"{ip}:{int(port)}"
            self.reputation.add(key, int(points))
            return True
        except Exception:
            return False

    def slash_peer(self, ip: str, port: int, points: int = 10) -> bool:
        try:
            key = f"{ip}:{int(port)}"
            self.reputation.add(key, -abs(int(points)))
            return True
        except Exception:
            return False

    # =============================== Core wrappers ===========================

    # ---- Account / keys ----
    def create_new_account(self) -> bool:
        # Use package-relative import so it works when frozen (PyInstaller)
        try:
            from .diac_dnc_client_core import DNCAuxiliary  # type: ignore
        except Exception as e:
            self.last_error = f"import diac_dnc_client_core failed: {e}"
            self._log(self.last_error)
            return False
        try:
            self.dnc = DNCAuxiliary(mode="new")
            return True
        except Exception as e:
            import traceback
            self.last_error = f"DNCAuxiliary(mode='new') failed: {e}\n{traceback.format_exc()}"
            self._log(self.last_error)
            return False

    def login_with_keys(self, public_key: str, private_key: str) -> bool:
        try:
            from .diac_dnc_client_core import DNCAuxiliary  # type: ignore
        except Exception as e:
            self.last_error = f"import diac_dnc_client_core failed: {e}"
            self._log(self.last_error)
            return False
        try:
            self.dnc = DNCAuxiliary(mode="login", public_key=public_key, private_key=private_key)
            return True
        except Exception as e:
            import traceback
            self.last_error = f"DNCAuxiliary(mode='login') failed: {e}\n{traceback.format_exc()}"
            self._log(self.last_error)
            return False

    def logout(self) -> None:
        self.dnc = None

    def get_public_key(self) -> str:
        try:
            return self.dnc.get_public_key() if self.dnc else ""
        except Exception:
            return ""

    def get_private_key(self) -> str:
        try:
            return self.dnc.get_private_key() if self.dnc else ""
        except Exception:
            return ""

    def get_address(self) -> str:
        try:
            return self.dnc.get_address() if self.dnc else ""
        except Exception:
            return ""

    # ---- Wallet / tx ----
    def get_balance(self) -> float:
        try:
            return float(self.dnc.get_balance()) if self.dnc else 0.0
        except Exception:
            return 0.0

    def get_recent_transactions(self) -> List[Dict[str, Any]]:
        try:
            return list(self.dnc.get_recent_transactions() or []) if self.dnc else []
        except Exception:
            return []

    def send_diac(self, recipient: str, amount: float) -> Tuple[bool, str]:
        if not self.dnc:
            return False, "Not logged in"
        try:
            tx = self.dnc.build_transaction(recipient, float(amount))
            ok, msg = self.dnc.validate_transaction(tx)
            if not ok:
                return False, f"Validation failed: {msg}"
            ok2, msg2 = self.dnc.apply_transaction(tx)
            return ok2, msg2
        except Exception as e:
            return False, str(e)

    # ---- Mining (simple loop) ----
    def _mining_loop(self) -> None:
        while not self._mining_stop.is_set():
            try:
                if self.dnc:
                    self.dnc.perform_mining_cycle()
            except Exception:
                pass
            # simple demo epoch interval
            self._mining_stop.wait(4.0)

    def start_mining(self) -> bool:
        if not self.dnc:
            return False
        if self._mining_thread and self._mining_thread.is_alive():
            return True
        self._mining_stop.clear()
        self._mining_thread = threading.Thread(target=self._mining_loop, daemon=True)
        self._mining_thread.start()
        return True

    def stop_mining(self) -> None:
        if self._mining_thread and self._mining_thread.is_alive():
            self._mining_stop.set()
            self._mining_thread.join(timeout=2.0)

    def get_mining_stats(self) -> Dict[str, Any]:
        if not self.dnc:
            return {"total_rewards": 0.0, "hourly_rate": 0.0, "completed_challenges": 0, "efficiency": 0.0}
        try:
            return dict(self.dnc.mining_stats)
        except Exception:
            return {"total_rewards": 0.0, "hourly_rate": 0.0, "completed_challenges": 0, "efficiency": 0.0}

    # ---- PoS (local demo for GUI) ----
    def load_pos_fragment_from_file(self, path: str) -> Tuple[bool, str]:
        try:
            p = Path(path)
            if not p.exists() or not p.is_file():
                return False, "File not found"
            data = p.read_bytes()
            self._pos_fragment_path = p
            self._pos_fragment_cache = data
            return True, f"Loaded {p.name} ({len(data)} bytes)"
        except Exception as e:
            return False, str(e)

    def self_pos_challenge_and_verify(self) -> Tuple[bool, Dict[str, Any]]:
        """
        Local demo challenge: take a ~32KB chunk and “verify” its hash.
        (For GUI demo only; not the formal PoS.)
        """
        if not self._pos_fragment_cache:
            return False, {"error": "No fragment loaded"}
        data = self._pos_fragment_cache
        if not data:
            return False, {"error": "Empty fragment"}
        size = len(data)
        chunk_len = min(32768, size)
        idx = 0 if size <= chunk_len else int(time.time()) % (size - chunk_len + 1)
        chunk = data[idx: idx + chunk_len]
        h = _sha256_hex(chunk).upper()
        return True, {"idx": idx, "ok": True, "chunk_len": len(chunk), "hash": h}

    # ---- Network PoS/Bandwidth helpers ----
    def pos_network_info(self, ip: str, port: int) -> Dict[str, Any]:
        resp = self._request(ip, int(port), {"op": "pos_info"})
        return resp or {"ok": False}

    def pos_network_read_slice(self, ip: str, port: int, idx: int, length: int = 32768) -> Dict[str, Any]:
        resp = self._request(ip, int(port), {"op": "pos_read_slice", "idx": int(idx), "length": int(length)})
        return resp or {"ok": False}

    def pos_network_challenge_any(self) -> Tuple[bool, Dict[str, Any]]:
        """
        Pick a random/first alive peer with a PoS fragment, request a 32KB slice,
        measure latency and verify hash. Returns (ok, result_dict).
        """
        import random
        peers = [p for p in (self.get_peers() or []) if p.get("ip") and p.get("port")]
        if not peers:
            return False, {"error": "No peers available"}
        random.shuffle(peers)

        chosen = None
        info = None
        for p in peers:
            r = self.pos_network_info(p["ip"], int(p["port"]))
            if r and r.get("ok") and r.get("has_fragment") and r.get("size", 0) > 0:
                chosen = p
                info = r
                break
        if not chosen:
            return False, {"error": "No peer with PoS fragment"}

        size = int(info.get("size", 0))
        L = min(32768, size) if size > 0 else 0
        if L <= 0:
            return False, {"error": "Peer fragment size invalid"}

        idx0 = random.randint(0, max(0, size - L))
        t0 = time.time()
        r2 = self.pos_network_read_slice(chosen["ip"], int(chosen["port"]), idx0, L)
        t1 = time.time()
        if not r2 or not r2.get("ok"):
            return False, {"error": "Slice request failed", "peer": f"{chosen['ip']}:{chosen['port']}"}

        data_b64 = r2.get("data_b64", "")
        try:
            chunk = base64.b64decode(data_b64)
        except Exception:
            chunk = b""

        hash_remote = str(r2.get("hash", "")).lower()
        hash_local = hashlib.sha256(chunk).hexdigest().lower()
        ok = (hash_local == hash_remote) and (len(chunk) == r2.get("length"))

        return ok, {
            "peer": f"{chosen['ip']}:{chosen['port']}",
            "idx": r2.get("idx"),
            "length": r2.get("length"),
            "latency_ms": int((t1 - t0) * 1000),
            "hash_ok": (hash_local == hash_remote),
            "bytes_ok": (len(chunk) == r2.get("length")),
        }