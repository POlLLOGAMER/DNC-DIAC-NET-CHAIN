# diac_dnc_gui.py (with Network PoS/PoB challenge)
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
from pathlib import Path

# Attempt to import the adapter from the current directory.  In some
# deployment scenarios (e.g. PyInstaller or when invoked from outside
# the source folder) the absolute import may fail.  Fallback to a
# relative import so that the module can still be resolved when
# ``dnc2`` is treated as a package.
try:
    from diac_dnc_adapter import DNCAdapter, DEFAULT_DIAC_PORT  # type: ignore
except ModuleNotFoundError:
    from .diac_dnc_adapter import DNCAdapter, DEFAULT_DIAC_PORT  # type: ignore

class DNCClientGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("DIAC NET CHAIN (DNC) - Client")
        self.root.geometry("940x680")
        self.root.minsize(940, 680)
        
        # Style
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('TButton', font=('Helvetica', 10), padding=5)
        self.style.configure('TLabel', font=('Helvetica', 10))
        self.style.configure('Header.TLabel', font=('Helvetica', 12, 'bold'))
        
        # Adapter
        self.dnc_adapter = DNCAdapter()
        self.is_logged_in = False
        self.mining_active = False
        
        # Config
        self.config_path = Path.home() / '.diac_dnc' / 'gui_config.json'
        self.config = {}
        self.load_config()
        
        # Tabs
        self.tab_control = ttk.Notebook(root)
        self.tab_login = ttk.Frame(self.tab_control)
        self.tab_wallet = ttk.Frame(self.tab_control)
        self.tab_mining = ttk.Frame(self.tab_control)
        self.tab_network = ttk.Frame(self.tab_control)
        self.tab_security = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_login, text='Home/Account')
        self.tab_control.add(self.tab_wallet, text='Wallet')
        self.tab_control.add(self.tab_mining, text='Mining')
        self.tab_control.add(self.tab_network, text='Network')
        self.tab_control.add(self.tab_security, text='Security')
        self.tab_control.pack(expand=1, fill="both")
        
        # UI
        self.setup_login_tab()
        self.setup_wallet_tab()
        self.setup_mining_tab()
        self.setup_network_tab()
        self.setup_security_tab()
        
        # Disable tabs if not logged
        if not self.is_logged_in:
            self.tab_control.tab(1, state='disabled')
            self.tab_control.tab(2, state='disabled')
            self.tab_control.tab(3, state='disabled')
            self.tab_control.tab(4, state='disabled')
        
        # On close
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Network selection
        if 'listen_port' in self.config:
            try:
                self.dnc_adapter.configure_network(int(self.config['listen_port']))
            except Exception as e:
                messagebox.showwarning("Port", f"Could not start server on {self.config['listen_port']}: {e}")
                self.ask_network_mode()
        else:
            self.ask_network_mode()
        
        # Update loop
        self.update_data()
    
    # ---------------- Config ----------------
    def load_config(self):
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    self.config = json.load(f)
                if 'public_key' in self.config and 'private_key' in self.config:
                    if self.dnc_adapter.login_with_keys(self.config['public_key'], self.config['private_key']):
                        self.is_logged_in = True
                        print("Auto login succeeded")
            except Exception as e:
                print(f"Error loading config: {e}")
    
    def save_config(self):
        cfg_dir = self.config_path.parent
        cfg_dir.mkdir(exist_ok=True)
        if self.is_logged_in:
            self.config['public_key'] = self.dnc_adapter.get_public_key()
            self.config['private_key'] = self.dnc_adapter.get_private_key()
        with open(self.config_path, 'w') as f:
            json.dump(self.config, f)
    
    # ---------------- Dialogs ----------------
    def ask_network_mode(self):
        dlg = NetworkModeDialog(self.root)
        self.root.wait_window(dlg.top)
        if dlg.ok:
            port = dlg.port if dlg.mode == 'central' else dlg.custom_port
            try:
                self.dnc_adapter.configure_network(int(port))
                self.config['listen_port'] = int(port)
                self.config['network_mode'] = dlg.mode
                self.save_config()
                messagebox.showinfo("Network", 
                    "Connected to Central DIAC (port 369)." if dlg.mode == 'central'
                    else f"Created/Joined your DIAC subnet on port {port}.")
            except Exception as e:
                messagebox.showerror("Network error", f"Failed to start server: {e}")
        else:
            messagebox.showwarning("Network", "No network was selected. You can set it up later from the Network tab.")
    
    # ---------------- Tabs: Home ----------------
    def setup_login_tab(self):
        frame = ttk.Frame(self.tab_login, padding=20)
        frame.pack(expand=True, fill='both')
        # ... (same as your current file) ...
        if self.is_logged_in:
            status_text = f"Logged in: {self.dnc_adapter.get_address()[:14]}..."
            status_color = "green"
        else:
            status_text = "You are not logged in"
            status_color = "red"
        status_label = ttk.Label(frame, text=status_text, foreground=status_color)
        status_label.grid(row=1, column=0, columnspan=2, pady=10)
        if not self.is_logged_in:
            create_btn = ttk.Button(frame, text="Create New Account", command=self.create_new_account)
            create_btn.grid(row=2, column=0, padx=10, pady=20, sticky='ew')
            login_btn = ttk.Button(frame, text="Log In with Keys", command=self.login_with_keys)
            login_btn.grid(row=2, column=1, padx=10, pady=20, sticky='ew')
    
    # ---------------- Tabs: Wallet ----------------
    def setup_wallet_tab(self):
        frame = ttk.Frame(self.tab_wallet, padding=20)
        frame.pack(expand=True, fill='both')
        balance_frame = ttk.LabelFrame(frame, text="Balance")
        balance_frame.pack(fill='x', pady=10)
        self.balance_label = ttk.Label(balance_frame, text="Loading balance...", font=('Helvetica', 16, 'bold'))
        self.balance_label.pack(pady=10)
        # ... list/history as in your version ...
    
    # ---------------- Tabs: Mining ----------------
    def setup_mining_tab(self):
        frame = ttk.Frame(self.tab_mining, padding=20)
        frame.pack(expand=True, fill='both')
        control_frame = ttk.LabelFrame(frame, text="Mining Control")
        control_frame.pack(fill='x', pady=10)
        self.mining_status_label = ttk.Label(control_frame, text="Status: Inactive", foreground="red")
        self.mining_status_label.pack(anchor='w', pady=10)
        self.mine_btn = ttk.Button(control_frame, text="Start Mining", command=self.toggle_mining)
        self.mine_btn.pack(anchor='w', pady=10)
        stats_frame = ttk.LabelFrame(frame, text="Mining Stats")
        stats_frame.pack(fill='both', expand=True, pady=10)
        self.rewards_label = ttk.Label(stats_frame, text="Total Rewards: 0 DIAC")
        self.rewards_label.pack(anchor='w', pady=5)
        self.rate_label = ttk.Label(stats_frame, text="Rate: 0 DIAC/hour")
        self.rate_label.pack(anchor='w', pady=5)
        self.challenges_label = ttk.Label(stats_frame, text="Completed Challenges: 0")
        self.challenges_label.pack(anchor='w', pady=5)
        self.efficiency_label = ttk.Label(stats_frame, text="Efficiency: 0%")
        self.efficiency_label.pack(anchor='w', pady=5)
    
    # ---------------- Tabs: Security ----------------
    def setup_security_tab(self):
        frame = ttk.Frame(self.tab_security, padding=20)
        frame.pack(expand=True, fill='both')
        # PoS/PoB section
        pos_frame = ttk.LabelFrame(frame, text="Proof of Storage / Bandwidth")
        pos_frame.pack(fill='x', pady=8)
        ttk.Button(pos_frame, text="Load Fragment File...", command=self.pos_load_file).grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.pos_status_label = ttk.Label(pos_frame, text="No fragment loaded"); self.pos_status_label.grid(row=0, column=1, padx=5, pady=5, sticky='w')
        ttk.Button(pos_frame, text="Self-Challenge (Local)", command=self.pos_self_challenge).grid(row=0, column=2, padx=5, pady=5, sticky='w')
        ttk.Button(pos_frame, text="Network Challenge (Auto)", command=self.pos_network_challenge).grid(row=0, column=3, padx=5, pady=5, sticky='w')
        self.pos_result_label = ttk.Label(pos_frame, text=""); self.pos_result_label.grid(row=0, column=4, padx=5, pady=5, sticky='w')
        # Reputation section (optional)
        rep_frame = ttk.LabelFrame(frame, text="Reputation & Slashing")
        rep_frame.pack(fill='both', pady=8, expand=True)
        ttk.Button(rep_frame, text="Refresh", command=self.rep_refresh).pack(anchor='w', padx=5, pady=5)
        rep_cols = ('peer','score')
        self.rep_tree = ttk.Treeview(rep_frame, columns=rep_cols, show='headings')
        self.rep_tree.heading('peer', text='Peer (ip:port)'); self.rep_tree.column('peer', width=260)
        self.rep_tree.heading('score', text='Score'); self.rep_tree.column('score', width=80, anchor='center')
        self.rep_tree.pack(fill='both', expand=True, padx=5, pady=5)
        rep_btns = ttk.Frame(rep_frame); rep_btns.pack(fill='x', padx=5, pady=5)
        ttk.Button(rep_btns, text="Reward +1", command=self.rep_reward_selected).pack(side='left', padx=5)
        ttk.Button(rep_btns, text="Slash -10", command=self.rep_slash_selected).pack(side='left', padx=5)

    # -------- PoS/PoB handlers --------
    def pos_load_file(self):
        if not self.is_logged_in:
            messagebox.showerror("PoS", "Log in first.")
            return
        path = filedialog.askopenfilename(title="Choose fragment file")
        if not path:
            return
        ok, msg = self.dnc_adapter.load_pos_fragment_from_file(path)
        self.pos_status_label.config(text=msg if ok else f"Error: {msg}")

    def pos_self_challenge(self):
        ok, res = self.dnc_adapter.self_pos_challenge_and_verify()
        if not ok:
            messagebox.showerror("PoS", str(res))
            return
        self.pos_result_label.config(text=f"[Local] idx={res['idx']}, ok={res['ok']}, chunk={res['chunk_len']}B")

    def pos_network_challenge(self):
        ok, res = self.dnc_adapter.pos_network_challenge_any()
        if not ok:
            messagebox.showerror("Network PoS/PoB", str(res))
            return
        self.pos_result_label.config(text=f"[Net] {res['peer']} • {res['length']}B • {res['latency_ms']}ms • hash_ok={res['hash_ok']}")

    # -------- Reputation handlers (optional) --------
    def rep_refresh(self):
        snap = self.dnc_adapter.get_reputation_snapshot()
        for i in getattr(self, 'rep_tree').get_children():
            self.rep_tree.delete(i)
        for peer, score in snap.items():
            self.rep_tree.insert('', 'end', values=(peer, score))

    def rep_reward_selected(self):
        sel = self.rep_tree.selection()
        if not sel:
            return
        peer, _ = self.rep_tree.item(sel[0])['values']
        if ':' in str(peer):
            ip, port = str(peer).split(':', 1)
            self.dnc_adapter.reward_peer(ip, int(port), 1)
            self.rep_refresh()

    def rep_slash_selected(self):
        sel = self.rep_tree.selection()
        if not sel:
            return
        peer, _ = self.rep_tree.item(sel[0])['values']
        if ':' in str(peer):
            ip, port = str(peer).split(':', 1)
            self.dnc_adapter.slash_peer(ip, int(port), 10)
            self.rep_refresh()

    # ---------------- Update loop ----------------
    def update_data(self):
        if self.is_logged_in:
            balance = self.dnc_adapter.get_balance()
            self.balance_label.config(text=f"{balance} DIAC")
        self.root.after(5000, self.update_data)

    def toggle_mining(self):
        if not self.mining_active:
            success = self.dnc_adapter.start_mining()
            if success:
                self.mining_active = True
                self.mining_status_label.config(text="Status: Active", foreground="green")
            else:
                messagebox.showerror("Error", "Could not start mining.")
        else:
            self.dnc_adapter.stop_mining()
            self.mining_active = False
            self.mining_status_label.config(text="Status: Inactive", foreground="red")

    def login_with_keys(self):
        messagebox.showinfo("Info", "Use your current login dialog (omitted in this snippet).")

    def create_new_account(self):
        if self.dnc_adapter.create_new_account():
            self.is_logged_in = True
            self.save_config()
            messagebox.showinfo("Account", "New account created.")

    def ask_network_mode(self):
        dlg = NetworkModeDialog(self.root)
        self.root.wait_window(dlg.top)
        if dlg.ok:
            port = dlg.port if dlg.mode == 'central' else dlg.custom_port
            self.dnc_adapter.configure_network(int(port))
            self.config['listen_port'] = int(port)
            self.config['network_mode'] = dlg.mode
            self.save_config()

    def on_closing(self):
        if self.mining_active:
            self.dnc_adapter.stop_mining()
        if self.is_logged_in:
            self.save_config()
        self.root.destroy()


class NetworkModeDialog:
    def __init__(self, parent):
        self.top = tk.Toplevel(parent); self.top.title("Choose DIAC Network Mode")
        self.ok = False
        self.mode = 'central'
        self.port = DEFAULT_DIAC_PORT
        self.custom_port = None
        frame = ttk.Frame(self.top, padding=20); frame.pack(fill='both', expand=True)
        ttk.Label(frame, text="Central (369) or Custom port?").pack(anchor='w')
        self.mode_var = tk.StringVar(value='central')
        ttk.Radiobutton(frame, text=f"Central (port {DEFAULT_DIAC_PORT})", variable=self.mode_var, value='central').pack(anchor='w')
        ttk.Radiobutton(frame, text="Custom", variable=self.mode_var, value='custom').pack(anchor='w')
        row = ttk.Frame(frame); row.pack(anchor='w', pady=6)
        ttk.Label(row, text="Port:").pack(side='left')
        self.port_entry = ttk.Entry(row, width=10); self.port_entry.insert(0, "5369"); self.port_entry.pack(side='left', padx=6)
        btns = ttk.Frame(frame); btns.pack(fill='x', pady=10)
        ttk.Button(btns, text="Cancel", command=self.cancel).pack(side='right', padx=5)
        ttk.Button(btns, text="OK", command=self.ok_clicked).pack(side='right', padx=5)
    def ok_clicked(self):
        self.mode = self.mode_var.get()
        if self.mode == 'central':
            self.ok = True; self.top.destroy()
            return
        try:
            p = int(self.port_entry.get().strip())
            if not (1 <= p <= 65535): raise ValueError
            self.custom_port = p; self.ok = True; self.top.destroy()
        except Exception:
            messagebox.showerror("Error", "Invalid port")
    def cancel(self):
        self.ok = False; self.top.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = DNCClientGUI(root)
    root.mainloop()
