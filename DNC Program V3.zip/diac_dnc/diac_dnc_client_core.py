
# diac_dnc_client_core.py - Core with keys, wallet, ledger, tx validation/apply.
import time, random, json, hashlib, base64, os, threading
from datetime import datetime
from pathlib import Path
import hmac

class DNCAuxiliary:
    def __init__(self, mode="new", public_key=None, private_key=None):
        self.base_path = Path.home() / '.diac_dnc'
        self.base_path.mkdir(exist_ok=True)
        self.peers = []
        self.mining_stats = {"total_rewards": 0, "hourly_rate": 0, "completed_challenges": 0, "efficiency": 0}
        self.ledger_fragment = {"balances": {}, "transactions": []}
        self.recent_transactions = []
        if mode == "new":
            self._generate_new_keys()
        elif mode == "existing":
            if not public_key or not private_key:
                raise ValueError("Both keys are required for 'existing' mode")
            self.public_key = public_key
            self.private_key = private_key
        else:
            raise ValueError("mode must be 'new' or 'existing'")
        self.address = self._derive_address_from_pubkey()
        if self.address not in self.ledger_fragment["balances"]:
            self.ledger_fragment["balances"][self.address] = 100.0
        self._load_or_init_peers()
        self._start_background_tasks()

    # Keys
    def _generate_new_keys(self):
        seed = os.urandom(32)
        self.private_key = base64.b64encode(seed).decode('utf-8')
        h = hashlib.sha256(); h.update(seed); h.update(b"DNC-pubkey-derivation")
        pub_seed = h.digest()
        self.public_key = base64.b64encode(pub_seed).decode('utf-8')

    def _derive_address_from_pubkey(self):
        h = hashlib.sha256(); h.update(self.public_key.encode('utf-8'))
        return f"DNC-{h.hexdigest()[:40]}"

    # Peers
    def _peers_file(self):
        return self.base_path / 'peers.json'

    def _save_peers(self):
        with open(self._peers_file(), 'w') as f:
            json.dump(self.peers, f, indent=2)

    def _load_or_init_peers(self):
        pf = self._peers_file()
        if pf.exists():
            try:
                self.peers = json.loads(pf.read_text(encoding="utf-8"))
            except Exception:
                self.peers = []; self._save_peers()
        else:
            self.peers = []; self._save_peers()

    def add_peer(self, ip: str, port: int, address: str = ""):
        ip = (ip or "").strip(); port = int(port); address = (address or "").strip()
        if not ip or not port: return False
        if not any((p.get("ip")==ip and int(p.get("port",0))==port) for p in self.peers):
            if not address:
                derived = hashlib.sha256(f"{ip}:{port}".encode()).hexdigest()[:40]
                address = f"DNC-{derived}"
            self.peers.append({"address": address, "ip": ip, "port": port, "last_seen": "1970-01-01T00:00:00"})
            self._save_peers()
            return True
        return False

    # Background
    def _start_background_tasks(self):
        t = threading.Thread(target=self._placeholder_sync, daemon=True); t.start()

    def _placeholder_sync(self):
        while True: time.sleep(30)

    # Wallet / TX
    def _ed25519_avail(self):
        try:
            import nacl.signing  # type: ignore
            return True
        except Exception:
            return False

    def _tx_core_bytes(self, tx: dict) -> bytes:
        import json
        core = {"from": tx.get("from",""), "to": tx.get("to",""), "amount": tx.get("amount",0), "ts": tx.get("ts",0), "nonce": tx.get("nonce","")}
        return json.dumps(core, sort_keys=True).encode("utf-8")

    def _sign_tx(self, tx: dict) -> dict:
        msg = self._tx_core_bytes(tx)
        if self._ed25519_avail():
            from nacl.signing import SigningKey  # type: ignore
            import base64 as _b64
            sk_seed = base64.b64decode(self.private_key.encode("utf-8"))
            sk = SigningKey(sk_seed)
            signed = sk.sign(msg); vk = sk.verify_key
            tx["sig_scheme"]="ed25519"; tx["pub_ed25519"]=_b64.b64encode(bytes(vk)).decode("utf-8"); tx["sig"]=_b64.b64encode(signed.signature).decode("utf-8")
        else:
            import hashlib, base64 as _b64
            key = base64.b64decode(self.private_key.encode("utf-8"))
            mac = hmac.new(key, msg, hashlib.sha256).hexdigest()
            tx["sig_scheme"]="hmac256"; tx["sig"]=mac
        return tx

    def _verify_tx_sig(self, tx: dict) -> bool:
        if tx.get("sig_scheme") == "ed25519":
            try:
                from nacl.signing import VerifyKey  # type: ignore
                import base64 as _b64
                vk = VerifyKey(_b64.b64decode(tx.get("pub_ed25519","")))
                vk.verify(self._tx_core_bytes(tx), _b64.b64decode(tx.get("sig","")))
                return True
            except Exception:
                return False
        elif tx.get("sig_scheme") == "hmac256":
            return True
        return False

    def build_transaction(self, recipient, amount):
        if not recipient.startswith("DNC-"):
            raise ValueError("Recipient address must start with 'DNC-'")
        if amount <= 0:
            raise ValueError("Amount must be positive")
        import os, time, hashlib
        ts = time.time(); nonce = os.urandom(12).hex()
        txid = hashlib.sha256(f"{self.address}-{recipient}-{amount}-{ts}-{nonce}".encode()).hexdigest()
        tx = {"txid": txid, "from": self.address, "to": recipient, "amount": amount, "timestamp": datetime.now().isoformat(), "ts": ts, "nonce": nonce, "pub_id": self.public_key}
        tx = self._sign_tx(tx); return tx

    def validate_transaction(self, tx):
        try:
            import time
            if not tx.get('to','').startswith('DNC-'): return False, 'Bad recipient'
            amt = float(tx.get('amount', 0))
            # Reject transactions with non-positive amounts
            if amt <= 0:
                return False, 'Bad amount'
            ts = float(tx.get('ts', 0)); 
            if abs(time.time() - ts) > 300: return False, 'Stale timestamp'
            sender = tx.get('from',''); bal = self.ledger_fragment['balances'].get(sender, 0)
            # Signature
            if not self._verify_tx_sig(tx): return False, 'Bad signature'
            return True, 'OK'
        except Exception as e:
            return False, str(e)

    def apply_transaction(self, tx):
        sender = tx.get("from",""); recipient = tx.get("to",""); amount = float(tx.get("amount",0))
        bal_from = self.ledger_fragment["balances"].get(sender, 0.0)
        if bal_from < amount and sender == self.address:
            return False, "Insufficient balance"
        self.ledger_fragment["balances"][sender] = bal_from - amount
        self.ledger_fragment["balances"][recipient] = self.ledger_fragment["balances"].get(recipient, 0.0) + amount
        self.ledger_fragment["transactions"].append(tx)
        self.recent_transactions.insert(0, {"timestamp": datetime.now().isoformat(),"type":"Send","address": recipient,"amount": amount,"status":"Confirmed"})
        if len(self.recent_transactions) > 50: self.recent_transactions = self.recent_transactions[:50]
        return True, "applied"

    def perform_mining_cycle(self):
        success = random.random() < 0.6
        if success:
            reward = round(random.uniform(0.05, 0.5), 4)
            self.ledger_fragment["balances"][self.address] = self.get_balance() + reward
            self.mining_stats["total_rewards"] += reward; self.mining_stats["completed_challenges"] += 1
            hourly_estimate = reward * 15; self.mining_stats["hourly_rate"] = round(hourly_estimate, 2)
            total_attempts = self.mining_stats.get("total_attempts", 0) + 1; self.mining_stats["total_attempts"] = total_attempts
            self.mining_stats["efficiency"] = round((self.mining_stats["completed_challenges"]/ total_attempts) * 100, 1)
            self.recent_transactions.insert(0, {"timestamp": datetime.now().isoformat(),"type":"Mining","address":"System","amount": reward,"status":"Confirmed"})
            if len(self.recent_transactions) > 50: self.recent_transactions = self.recent_transactions[:50]
            return True
        else:
            total_attempts = self.mining_stats.get("total_attempts", 0) + 1; self.mining_stats["total_attempts"] = total_attempts
            self.mining_stats["efficiency"] = round((self.mining_stats["completed_challenges"]/ total_attempts) * 100, 1); return False

    # Exposed
    def get_address(self): return self.address
    def get_public_key(self): return self.public_key
    def get_private_key(self): return self.private_key
    def get_balance(self): return self.ledger_fragment["balances"].get(self.address, 0)
    def get_recent_transactions(self): return self.recent_transactions
    def get_peers_list(self): return self.peers

    # Fragment merge
    def merge_fragment(self, remote_frag: dict):
        """
        Replace the local ledger fragment with a remote fragment.

        This method overwrites the current ledger_fragment with the provided
        remote fragment when called. It is used as part of the simplified
        Majority-Value Synchronisation process to adopt the majority view from
        peers. All existing balances and transactions will be replaced with
        those from the remote fragment. Recent transactions are updated to
        reflect the new history.

        A production-ready implementation would verify the integrity of the
        fragment before adoption (e.g. via cryptographic proofs) and merge
        transaction histories appropriately. Here we prioritise restoring
        consensus quickly over forensic reconciliation.
        """
        if not remote_frag or not isinstance(remote_frag, dict):
            return
        try:
            # Overwrite local ledger fragment completely
            self.ledger_fragment = {
                "balances": dict(remote_frag.get("balances", {})),
                "transactions": list(remote_frag.get("transactions", [])),
            }
            # Reset recent transactions based on the remote fragment (up to 50 latest)
            self.recent_transactions = []
            for tx in reversed(self.ledger_fragment.get("transactions", [])):
                # Build a basic entry; use timestamp from tx if available
                ts = tx.get("timestamp") or datetime.now().isoformat()
                entry = {
                    "timestamp": ts,
                    "type": tx.get("type", "Sync"),
                    "address": tx.get("to", ""),
                    "amount": tx.get("amount", 0),
                    "status": "Synced",
                }
                self.recent_transactions.insert(0, entry)
                if len(self.recent_transactions) >= 50:
                    break
        except Exception:
            # ignore errors; local state remains unchanged
            pass
