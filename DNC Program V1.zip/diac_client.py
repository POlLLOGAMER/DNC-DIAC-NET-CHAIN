
# diac_client.py
import os, sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import tkinter as tk
from diac_dnc_gui import DNCClientGUI

if __name__ == '__main__':
    root = tk.Tk()
    app = DNCClientGUI(root)
    root.mainloop()
