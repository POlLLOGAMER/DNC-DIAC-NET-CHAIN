
# range_zkp.py - Real range proofs using Bulletproofs (via petlib) with equality-binding.
# Requirements:
#   pip install petlib bulletproofs
#
# API:
#   commit(value: int) -> (C_bytes, blinding_bytes)
#   prove_range(value: int, blinding_bytes: bytes, nbits: int=32) -> proof_bytes
#   verify_range(C_bytes: bytes, proof_bytes: bytes, nbits: int=32) -> bool
#   prove_balance_ge(value: int, blinding_bytes: bytes, threshold: int, nbits: int=32) -> (C_bytes, Cshift_bytes, proof_bytes)
#   verify_balance_ge(C_bytes: bytes, Cshift_bytes: bytes, proof_bytes: bytes, threshold: int, nbits: int=32) -> bool
#
def _bp_ctx_ok():
    try:
        from bulletproofs import BulletProofBuilder, VectorPedersen
        from petlib.ec import EcGroup
        return True
    except Exception:
        return False

def _ensure():
    if not _bp_ctx_ok():
        raise RuntimeError("Bulletproofs not available. Install with: pip install petlib bulletproofs")

def commit(value: int):
    _ensure()
    from petlib.ec import EcGroup
    from bulletproofs import VectorPedersen
    G = EcGroup()
    vp = VectorPedersen(G)
    r = G.order().random()
    C = vp.commit(value, r)
    return C.export(), r.binary()

def prove_range(value: int, blinding_bytes: bytes, nbits: int = 32):
    _ensure()
    from petlib.ec import EcGroup, Bn
    from bulletproofs import BulletProofBuilder, VectorPedersen
    G = EcGroup()
    vp = VectorPedersen(G)
    r = Bn.from_binary(blinding_bytes) % G.order()
    C = vp.commit(value, r)
    bp = BulletProofBuilder(G, vp, nbits)
    proof = bp.prove([value], [r])
    return proof.export()

def verify_range(C_bytes: bytes, proof_bytes: bytes, nbits: int = 32) -> bool:
    _ensure()
    from petlib.ec import EcGroup
    from bulletproofs import BulletProofBuilder, VectorPedersen, BulletProof
    G = EcGroup()
    vp = VectorPedersen(G)
    bp = BulletProofBuilder(G, vp, nbits)
    C = vp.group.element_from_bytes(C_bytes)
    try:
        proof = BulletProof.import_(G, proof_bytes)
        return bp.verify([C], proof)
    except Exception:
        return False

def prove_balance_ge(value: int, blinding_bytes: bytes, threshold: int, nbits: int = 32):
    """Return (C, C_shift, proof) bound by equality: C_shift == C + commit(-threshold, 0)."""
    _ensure()
    from petlib.ec import EcGroup, Bn
    from bulletproofs import BulletProofBuilder, VectorPedersen
    G = EcGroup()
    vp = VectorPedersen(G)
    r = Bn.from_binary(blinding_bytes) % G.order()
    # Base commitment
    C = vp.commit(value, r)
    v_shift = value - threshold
    if v_shift < 0:
        raise ValueError("Value below threshold; cannot prove >= threshold")
    C_shift = vp.commit(v_shift, r)
    bp = BulletProofBuilder(G, vp, nbits)
    proof = bp.prove([v_shift], [r])
    return C.export(), C_shift.export(), proof.export()

def verify_balance_ge(C_bytes: bytes, Cshift_bytes: bytes, proof_bytes: bytes, threshold: int, nbits: int = 32) -> bool:
    """Verify bulletproof on C_shift and check equality binding to C with the same VectorPedersen bases."""
    _ensure()
    from petlib.ec import EcGroup
    from bulletproofs import BulletProofBuilder, VectorPedersen, BulletProof
    G = EcGroup()
    vp = VectorPedersen(G)
    try:
        # 1) Range proof on C_shift
        bp = BulletProofBuilder(G, vp, nbits)
        C_shift = vp.group.element_from_bytes(Cshift_bytes)
        proof = BulletProof.import_(G, proof_bytes)
        ok = bp.verify([C_shift], proof)
        if not ok:
            return False
        # 2) Equality binding: C_shift == C + commit(-threshold, 0)
        C = vp.group.element_from_bytes(C_bytes)
        negt = vp.commit(-int(threshold), 0)  # -t*G
        return (C + negt) == C_shift
    except Exception:
        return False
