
# deps_bootstrap.py
# Simple bootstrap that tries to install cryptographic deps when running from source.
# Works when sys.executable is a real Python (not PyInstaller one-file exe).
import sys, subprocess

PKGS = [
    ("petlib", "petlib"),
    ("bulletproofs", "bulletproofs"),
    ("pynacl", "nacl"),  # optional
]

def ensure_deps(interactive: bool = True) -> None:
    missing = []
    for pkg, mod in PKGS:
        try:
            __import__(mod)
        except Exception:
            missing.append(pkg)
    if not missing:
        return

    # If running from a frozen EXE, we can't use pip here.
    if getattr(sys, "frozen", False):
        if interactive:
            print("[DNC] This EXE cannot auto-install:", ", ".join(missing))
            print("[DNC] Rebuild with dependencies installed, or install system-wide and run from source.")
        return

    # Try to install with pip
    try:
        print("[DNC] Installing:", ", ".join(missing))
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade"] + missing)
        print("[DNC] Dependencies installed.")
    except Exception as e:
        if interactive:
            print("[DNC] Failed to install dependencies:", e)
        # do not raise
