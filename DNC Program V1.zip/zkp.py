
# zkp.py - Nonce-bound educational ZKP demo for "balance >= threshold" without revealing balance.
# Commitment: C = SHA256(salt || balance_bytes)
# Proof: P = SHA256(C || nonce || threshold_bytes || flag), where flag=1 if balance>=threshold else random-but-we return only if true.
# Verifier: recompute P with received C, nonce, threshold and flag=1. (Does not reveal balance).
# NOTE: This is NOT a real ZKP; it's a nonce-bound attest demo for distributed message flow.
import os, hashlib, struct

def commit_balance(balance: float, salt: bytes = None):
    if salt is None:
        salt = os.urandom(16)
    b = struct.pack(">d", balance)
    C = hashlib.sha256(salt + b).hexdigest()
    return C, salt.hex()

def prove_balance_ge(balance: float, threshold: float, nonce_hex: str, salt_hex: str):
    C = hashlib.sha256(bytes.fromhex(salt_hex) + struct.pack(">d", balance)).hexdigest()
    if balance >= threshold:
        P = hashlib.sha256(bytes.fromhex(C) + bytes.fromhex(nonce_hex) + struct.pack(">d", threshold) + b"\x01").hexdigest()
        return {"commitment": C, "salt_hex": salt_hex, "proof": P}
    else:
        # refuse to prove
        return {"commitment": C, "salt_hex": salt_hex, "proof": ""}

def verify_balance_ge(commitment_hex: str, threshold: float, nonce_hex: str, proof_hex: str) -> bool:
    expect = hashlib.sha256(bytes.fromhex(commitment_hex) + bytes.fromhex(nonce_hex) + struct.pack(">d", threshold) + b"\x01").hexdigest()
    return proof_hex == expect and len(proof_hex) == 64
