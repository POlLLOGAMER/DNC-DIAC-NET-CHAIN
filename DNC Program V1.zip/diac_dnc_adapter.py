# diac_dnc_adapter.py
import socket
import threading
import json
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

# Módulos locales
from reputation import Reputation

# Puerto “central” por defecto (usado por la GUI)
DEFAULT_DIAC_PORT = 369


def _sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


class DNCAdapter:
    """
    Adaptador entre la GUI y el core (DNCAuxiliary), con:
      - Servidor TCP JSON simple para P2P
      - Descubrimiento/intercambio de peers por RPC
      - Majority-Value Synchronisation (MVS) básico
      - Reputación local (para GUI)
      - Wrappers a funciones del core (cuenta, tx, minería, PoS demo)
    """
    def __init__(self):
        # Core (lo fija la GUI al crear/loguearse)
        self.dnc = None  # tipo: DNCAuxiliary

        # Red
        self.listen_port: int = 0
        self._server_thread: Optional[threading.Thread] = None
        self._stop_server = threading.Event()

        # Reputación (local)
        # Inicializa Reputation pasando un Path (no str) para evitar 'str' / 'str'.
        data_dir = Path.home() / '.diac_dnc'
        data_dir.mkdir(parents=True, exist_ok=True)
        try:
            # Preferimos pasar un directorio Path
            self.reputation = Reputation(base_path=data_dir)
        except TypeError:
            # Algunas variantes aceptan sin argumentos
            try:
                self.reputation = Reputation()
            except TypeError:
                # Otras variantes esperan un archivo Path
                self.reputation = Reputation(base_path=(data_dir / 'reputation.json'))

        # Estado MVS
        self._mvs_synced: bool = False
        self._last_mvs_time: float = 0.0

        # Minería (wrapper)
        self._mining_thread: Optional[threading.Thread] = None
        self._mining_stop = threading.Event()

        # PoS (demo local)
        self._pos_fragment_path: Optional[Path] = None
        self._pos_fragment_cache: Optional[bytes] = None

    # ====================== Configuración de red / servidor ======================

    def configure_network(self, port: int) -> None:
        """Inicia el servidor TCP simple en `port`."""
        if self._server_thread and self._server_thread.is_alive():
            # detener servidor previo si cambia de puerto
            self._stop_server.set()
            try:
                socket.create_connection(("127.0.0.1", self.listen_port), timeout=0.5).close()
            except Exception:
                pass
            self._server_thread.join(timeout=2.0)

        self.listen_port = int(port)
        self._stop_server.clear()
        self._server_thread = threading.Thread(target=self._server_loop, daemon=True)
        self._server_thread.start()
        print(f"[DNCAdapter] Server on port {self.listen_port}")

    def _server_loop(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("", self.listen_port))
            s.listen(64)
            s.settimeout(0.5)
            while not self._stop_server.is_set():
                try:
                    conn, addr = s.accept()
                except socket.timeout:
                    continue
                threading.Thread(target=self._handle_conn, args=(conn, addr), daemon=True).start()
        finally:
            try:
                s.close()
            except Exception:
                pass

    def _handle_conn(self, conn: socket.socket, addr: Tuple[str, int]):
        data = b""
        conn.settimeout(5.0)
        try:
            while True:
                chunk = conn.recv(65536)
                if not chunk:
                    break
                data += chunk
                if len(chunk) < 65536:
                    break
            if not data:
                return
            req = json.loads(data.decode("utf-8", errors="ignore"))
            op = req.get("op", "").strip()
        except Exception:
            try:
                conn.sendall(json.dumps({"ok": False, "error": "bad_request"}).encode("utf-8"))
            except Exception:
                pass
            conn.close()
            return

        # --- RPCs soportados ---
        try:
            if op == "ping":
                out = {"ok": True, "pong": True, "port": self.listen_port, "time": time.time()}
                conn.sendall(json.dumps(out).encode("utf-8"))
                conn.close()
                return

            if op == "getpeerlist":
                peers = self.get_peers()
                conn.sendall(json.dumps({"ok": True, "peers": peers}).encode("utf-8"))
                conn.close()
                return

            if op == "peer_exchange":
                inc = req.get("peers", [])
                merged = 0
                for p in inc:
                    try:
                        ip = str(p.get("ip", "")).strip()
                        port = int(p.get("port", 0))
                        addr_str = str(p.get("address", "")).strip()
                        if ip and port:
                            if self.add_peer(ip, port, addr_str):
                                merged += 1
                    except Exception:
                        continue
                mine = self.get_peers()
                conn.sendall(json.dumps({"ok": True, "merged": merged, "peers": mine}).encode("utf-8"))
                conn.close()
                return

            if op == "get_synopsis":
                syn = self._get_synopsis()
                conn.sendall(json.dumps({"ok": True, "synopsis": syn}).encode("utf-8"))
                conn.close()
                return

            if op == "fragment_request":
                frag = self._get_fragment_snapshot()
                conn.sendall(json.dumps({"ok": True, "fragment": frag}).encode("utf-8"))
                conn.close()
                return

            # Si no coincide nada
            conn.sendall(json.dumps({"ok": False, "error": "unknown_op"}).encode("utf-8"))
            conn.close()
        except Exception as e:
            try:
                conn.sendall(json.dumps({"ok": False, "error": f"server_err:{e}"}).encode("utf-8"))
            except Exception:
                pass
            conn.close()

    def _request(self, ip: str, port: int, payload: Dict[str, Any], timeout: float = 3.5) -> Optional[Dict[str, Any]]:
        """Realiza una solicitud JSON a un peer."""
        try:
            with socket.create_connection((ip, int(port)), timeout=timeout) as c:
                c.sendall(json.dumps(payload).encode("utf-8"))
                c.shutdown(socket.SHUT_WR)
                chunks = []
                c.settimeout(timeout)
                while True:
                    chunk = c.recv(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    if len(chunk) < 65536:
                        break
            if not chunks:
                return None
            raw = b"".join(chunks)
            return json.loads(raw.decode("utf-8", errors="ignore"))
        except Exception:
            return None

    # =========================== Peer management ============================

    def add_peer(self, ip: str, port: int, address: str = "") -> bool:
        """Agrega un peer al core (DNCAuxiliary)."""
        if not self.dnc:
            return False
        try:
            return bool(self.dnc.add_peer(str(ip).strip(), int(port), address))
        except Exception:
            return False

    def get_peers(self) -> List[Dict[str, Any]]:
        """Obtiene la lista de peers del core."""
        if not self.dnc:
            return []
        try:
            return list(self.dnc.get_peers_list() or [])
        except Exception:
            return []

    def ping_peers_real(self, peers: List[Dict[str, Any]]) -> int:
        """Ping a peers y actualiza last_seen; devuelve cantidad activos."""
        alive = 0
        now = datetime.now().isoformat()
        for p in peers or []:
            ip = p.get("ip")
            port = p.get("port")
            if not ip or not port:
                continue
            r = self._request(ip, int(port), {"op": "ping"})
            if r and r.get("ok"):
                alive += 1
                try:
                    p["last_seen"] = now
                except Exception:
                    pass
        return alive

    def discover_peers(self) -> int:
        """
        Intercambia listas de peers con los conocidos.
        Devuelve cuántos peers nuevos se intentaron fusionar (aprox).
        """
        peers = self.get_peers()
        total_merged = 0
        mine = peers
        for p in peers:
            ip = p.get("ip")
            port = p.get("port")
            if not ip or not port:
                continue
            resp = self._request(ip, int(port), {"op": "peer_exchange", "peers": mine})
            if resp and resp.get("ok"):
                total_merged += int(resp.get("merged", 0))
                # también integramos su lista por si trae algo nuevo
                for q in resp.get("peers", []):
                    try:
                        if self.add_peer(q.get("ip"), int(q.get("port")), q.get("address", "")):
                            total_merged += 1
                    except Exception:
                        continue
        return total_merged

    # =============================== MVS ===================================

    def _get_fragment_snapshot(self) -> Dict[str, Any]:
        """Copia segura del fragmento local (balances y transacciones)."""
        if not self.dnc:
            return {"balances": {}, "transactions": []}
        try:
            frag = self.dnc.ledger_fragment
            # copia superficial: balances y transacciones
            return {
                "balances": dict(frag.get("balances", {})),
                "transactions": list(frag.get("transactions", [])),
            }
        except Exception:
            return {"balances": {}, "transactions": []}

    def _get_synopsis(self) -> Dict[str, Any]:
        """
        Calcula la sinopsis: txCount, balance local y digest rolling del fragmento.
        """
        tx_count = 0
        my_balance = 0.0
        digest = "0" * 64
        if not self.dnc:
            return {"txCount": tx_count, "balance": my_balance, "digest": digest}
        try:
            frag = self.dnc.ledger_fragment
            txs = frag.get("transactions", [])
            tx_count = len(txs)
            my_balance = float(self.dnc.get_balance())
            # digest basado en balances ordenados + txids ordenados
            items = []
            for k, v in sorted(frag.get("balances", {}).items()):
                items.append(f"B|{k}|{v}")
            for t in sorted((t.get("txid", "") for t in txs)):
                items.append(f"T|{t}")
            digest = _sha256_hex("\n".join(items).encode("utf-8"))
        except Exception:
            pass
        return {"txCount": tx_count, "balance": my_balance, "digest": digest}

    @staticmethod
    def _mode_value(values: List[Any]) -> Optional[Any]:
        """Moda simple (por igualdad)."""
        if not values:
            return None
        freq: Dict[Any, int] = {}
        for v in values:
            freq[v] = freq.get(v, 0) + 1
        # valor con mayor frecuencia
        return max(freq.items(), key=lambda kv: kv[1])[0]

    def update_mvs(self) -> None:
        """
        Recolecta sinopsis de peers, calcula moda por campo y si hay desacuerdo
        intenta adoptar el fragmento mayoritario.
        """
        if not self.dnc:
            self._mvs_synced = False
            return

        local = self._get_synopsis()
        synopses: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []  # (peer, syn)
        for p in self.get_peers():
            ip = p.get("ip")
            port = p.get("port")
            if not ip or not port:
                continue
            resp = self._request(ip, int(port), {"op": "get_synopsis"})
            if resp and resp.get("ok"):
                syn = resp.get("synopsis", {})
                synopses.append((p, syn))

        if not synopses:
            # Sin muestras: considerar no sincronizado (o triv.)
            self._mvs_synced = False
            return

        tx_counts = [s[1].get("txCount") for s in synopses if isinstance(s[1].get("txCount"), int)]
        balances = [round(float(s[1].get("balance", 0.0)), 8) for s in synopses]
        digests = [s[1].get("digest") for s in synopses if isinstance(s[1].get("digest"), str)]

        mode_tx = self._mode_value(tx_counts)
        mode_bal = self._mode_value(balances)
        mode_dig = self._mode_value(digests)

        disagreement = False
        if mode_tx is not None and local.get("txCount") != mode_tx:
            disagreement = True
        if mode_dig and local.get("digest") != mode_dig:
            disagreement = True
        # El balance local puede diferir ligeramente; no lo usamos como criterio duro.

        self._mvs_synced = not disagreement
        self._last_mvs_time = time.time()

        # Si hay desacuerdo, intentamos adoptar el fragmento del peer cuyo digest es el mayoritario
        if disagreement and mode_dig:
            # Elegimos un peer con ese digest
            chosen_peer = None
            for p, syn in synopses:
                if syn.get("digest") == mode_dig:
                    chosen_peer = p
                    break
            if chosen_peer:
                frag_resp = self._request(chosen_peer.get("ip"), int(chosen_peer.get("port")), {"op": "fragment_request"})
                if frag_resp and frag_resp.get("ok"):
                    frag = frag_resp.get("fragment", {})
                    try:
                        # Fusión: sustituimos por el fragmento recibido
                        self.dnc.merge_fragment(frag)
                        # Recalcular sinopsis local y estado
                        local2 = self._get_synopsis()
                        self._mvs_synced = (local2.get("digest") == mode_dig)
                    except Exception:
                        # Si falla la fusión, permanecemos out-of-sync
                        pass

    def get_network_stats(self) -> Dict[str, Any]:
        """Devuelve métricas para la GUI."""
        peers = self.get_peers()
        connected = self.ping_peers_real(peers)
        # Ejecuta un ciclo de MVS rápido
        self.update_mvs()
        return {
            "connected_peers": connected,
            "synced_fragments": 0,  # placeholder: no contamos fragmentos por ahora
            "mvs_synced": bool(self._mvs_synced),
        }

    # ============================= Reputación ==============================

    def get_reputation_snapshot(self) -> Dict[str, int]:
        """Devuelve {'ip:port': score}."""
        try:
            return self.reputation.snapshot()
        except Exception:
            return {}

    def reward_peer(self, ip: str, port: int, points: int = 1) -> bool:
        try:
            key = f"{ip}:{int(port)}"
            self.reputation.add(key, int(points))
            return True
        except Exception:
            return False

    def slash_peer(self, ip: str, port: int, points: int = 10) -> bool:
        try:
            key = f"{ip}:{int(port)}"
            self.reputation.add(key, -abs(int(points)))
            return True
        except Exception:
            return False

    # ============================= Wrappers Core ===========================

    # ---- Cuenta / llaves ----
    def create_new_account(self) -> bool:
        try:
            from diac_dnc_client_core import DNCAuxiliary
            self.dnc = DNCAuxiliary(mode="new")
            return True
        except Exception:
            return False

    def login_with_keys(self, public_key: str, private_key: str) -> bool:
        try:
            from diac_dnc_client_core import DNCAuxiliary
            self.dnc = DNCAuxiliary(mode="login", public_key=public_key, private_key=private_key)
            return True
        except Exception:
            return False

    def logout(self) -> None:
        self.dnc = None

    def get_public_key(self) -> str:
        try:
            return self.dnc.get_public_key() if self.dnc else ""
        except Exception:
            return ""

    def get_private_key(self) -> str:
        try:
            return self.dnc.get_private_key() if self.dnc else ""
        except Exception:
            return ""

    def get_address(self) -> str:
        try:
            return self.dnc.get_address() if self.dnc else ""
        except Exception:
            return ""

    # ---- Wallet / tx ----
    def get_balance(self) -> float:
        try:
            return float(self.dnc.get_balance()) if self.dnc else 0.0
        except Exception:
            return 0.0

    def get_recent_transactions(self) -> List[Dict[str, Any]]:
        try:
            return list(self.dnc.get_recent_transactions() or []) if self.dnc else []
        except Exception:
            return []

    def send_diac(self, recipient: str, amount: float) -> Tuple[bool, str]:
        if not self.dnc:
            return False, "Not logged in"
        try:
            tx = self.dnc.build_transaction(recipient, float(amount))
            ok, msg = self.dnc.validate_transaction(tx)
            if not ok:
                return False, f"Validation failed: {msg}"
            ok2, msg2 = self.dnc.apply_transaction(tx)
            return ok2, msg2
        except Exception as e:
            return False, str(e)

    # ---- Minería (loop simple) ----
    def _mining_loop(self):
        while not self._mining_stop.is_set():
            try:
                if self.dnc:
                    self.dnc.perform_mining_cycle()
            except Exception:
                pass
            # intervalo de “epoch” de demo
            self._mining_stop.wait(4.0)

    def start_mining(self) -> bool:
        if not self.dnc:
            return False
        if self._mining_thread and self._mining_thread.is_alive():
            return True
        self._mining_stop.clear()
        self._mining_thread = threading.Thread(target=self._mining_loop, daemon=True)
        self._mining_thread.start()
        return True

    def stop_mining(self) -> None:
        if self._mining_thread and self._mining_thread.is_alive():
            self._mining_stop.set()
            self._mining_thread.join(timeout=2.0)

    def get_mining_stats(self) -> Dict[str, Any]:
        if not self.dnc:
            return {"total_rewards": 0.0, "hourly_rate": 0.0, "completed_challenges": 0, "efficiency": 0.0}
        try:
            return dict(self.dnc.mining_stats)
        except Exception:
            return {"total_rewards": 0.0, "hourly_rate": 0.0, "completed_challenges": 0, "efficiency": 0.0}

    # ---- PoS (demo local para GUI) ----
    def load_pos_fragment_from_file(self, path: str) -> Tuple[bool, str]:
        try:
            p = Path(path)
            if not p.exists() or not p.is_file():
                return False, "File not found"
            data = p.read_bytes()
            self._pos_fragment_path = p
            self._pos_fragment_cache = data
            return True, f"Loaded {p.name} ({len(data)} bytes)"
        except Exception as e:
            return False, str(e)

    def self_pos_challenge_and_verify(self) -> Tuple[bool, Dict[str, Any]]:
        """
        Desafío local simple: toma un chunk de ~32KB y “verifica” su hash.
        (Sólo para demo de GUI; no es el PoS formal del paper).
        """
        if not self._pos_fragment_cache:
            return False, {"error": "No fragment loaded"}
        data = self._pos_fragment_cache
        if not data:
            return False, {"error": "Empty fragment"}
        size = len(data)
        chunk_len = min(32768, size)
        idx = 0 if size <= chunk_len else int(time.time()) % (size - chunk_len + 1)
        chunk = data[idx: idx + chunk_len]
        h = _sha256_hex(chunk).upper()
        return True, {"idx": idx, "ok": True, "chunk_len": len(chunk), "hash": h}
