# diac_client.py
import tkinter as tk
from diac_dnc_gui import DNCClientGUI

if __name__ == '__main__':
    root = tk.Tk()
    app = DNCClientGUI(root)
    root.mainloop()
