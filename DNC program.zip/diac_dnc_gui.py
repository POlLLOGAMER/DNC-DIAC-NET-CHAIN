# diac_dnc_gui.py
import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
from pathlib import Path

from diac_dnc_adapter import DNCAdapter, DEFAULT_DIAC_PORT

class DNCClientGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("DIAC NET CHAIN (DNC) - Client")
        self.root.geometry("940x680")
        self.root.minsize(940, 680)
        
        # Style
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('TButton', font=('Helvetica', 10), padding=5)
        self.style.configure('TLabel', font=('Helvetica', 10))
        self.style.configure('Header.TLabel', font=('Helvetica', 12, 'bold'))
        
        # Adapter
        self.dnc_adapter = DNCAdapter()
        self.is_logged_in = False
        self.mining_active = False
        
        # Config
        self.config_path = Path.home() / '.diac_dnc' / 'gui_config.json'
        self.config = {}
        self.load_config()
        
        # Tabs
        self.tab_control = ttk.Notebook(root)
        self.tab_login = ttk.Frame(self.tab_control)
        self.tab_wallet = ttk.Frame(self.tab_control)
        self.tab_mining = ttk.Frame(self.tab_control)
        self.tab_network = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_login, text='Home/Account')
        self.tab_control.add(self.tab_wallet, text='Wallet')
        self.tab_control.add(self.tab_mining, text='Mining')
        self.tab_control.add(self.tab_network, text='Network')
        self.tab_control.pack(expand=1, fill="both")
        
        # UI
        self.setup_login_tab()
        self.setup_wallet_tab()
        self.setup_mining_tab()
        self.setup_network_tab()
        
        # Disable tabs if not logged
        if not self.is_logged_in:
            self.tab_control.tab(1, state='disabled')
            self.tab_control.tab(2, state='disabled')
            self.tab_control.tab(3, state='disabled')
        
        # On close
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Network selection (central 369 or custom subnet)
        if 'listen_port' in self.config:
            try:
                self.dnc_adapter.configure_network(int(self.config['listen_port']))
            except Exception as e:
                messagebox.showwarning("Port", f"Could not start server on {self.config['listen_port']}: {e}")
                self.ask_network_mode()
        else:
            self.ask_network_mode()
        
        # Update loop
        self.update_data()
    
    # ---------------- Config ----------------
    def load_config(self):
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    self.config = json.load(f)
                # Auto-login if keys present
                if 'public_key' in self.config and 'private_key' in self.config:
                    if self.dnc_adapter.login_with_keys(self.config['public_key'], self.config['private_key']):
                        self.is_logged_in = True
                        print("Auto login succeeded")
            except Exception as e:
                print(f"Error loading config: {e}")
    
    def save_config(self):
        cfg_dir = self.config_path.parent
        cfg_dir.mkdir(exist_ok=True)
        if self.is_logged_in:
            self.config['public_key'] = self.dnc_adapter.get_public_key()
            self.config['private_key'] = self.dnc_adapter.get_private_key()
        with open(self.config_path, 'w') as f:
            json.dump(self.config, f)
    
    # ---------------- Dialogs ----------------
    def ask_network_mode(self):
        """Ask the user to join Central DIAC (port 369) or create a custom subnet (custom port)."""
        dlg = NetworkModeDialog(self.root)
        self.root.wait_window(dlg.top)
        if dlg.ok:
            port = dlg.port if dlg.mode == 'central' else dlg.custom_port
            try:
                self.dnc_adapter.configure_network(int(port))
                self.config['listen_port'] = int(port)
                self.config['network_mode'] = dlg.mode
                self.save_config()
                messagebox.showinfo("Network", 
                    "Connected to Central DIAC (port 369)." if dlg.mode == 'central'
                    else f"Created/Joined your DIAC subnet on port {port}.")
            except Exception as e:
                messagebox.showerror("Network error", f"Failed to start server: {e}")
        else:
            messagebox.showwarning("Network", "No network was selected. You can set it up later from the Network tab.")
    
    # ---------------- Tabs: Home ----------------
    def setup_login_tab(self):
        frame = ttk.Frame(self.tab_login, padding=20)
        frame.pack(expand=True, fill='both')
        
        logo_label = ttk.Label(frame, text="DIAC NET CHAIN", font=('Helvetica', 20, 'bold'))
        logo_label.grid(row=0, column=0, columnspan=2, pady=20)
        
        if self.is_logged_in:
            status_text = f"Logged in: {self.dnc_adapter.get_address()[:14]}..."
            status_color = "green"
        else:
            status_text = "You are not logged in"
            status_color = "red"
        
        status_label = ttk.Label(frame, text=status_text, foreground=status_color)
        status_label.grid(row=1, column=0, columnspan=2, pady=10)
        
        if not self.is_logged_in:
            create_btn = ttk.Button(frame, text="Create New Account", command=self.create_new_account)
            create_btn.grid(row=2, column=0, padx=10, pady=20, sticky='ew')
            
            login_btn = ttk.Button(frame, text="Log In with Keys", command=self.login_with_keys)
            login_btn.grid(row=2, column=1, padx=10, pady=20, sticky='ew')
        else:
            account_frame = ttk.LabelFrame(frame, text="Account Info")
            account_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=10, sticky='ew')
            addr_label = ttk.Label(account_frame, text=f"Address: {self.dnc_adapter.get_address()}")
            addr_label.pack(anchor='w', pady=5)
            
            key_btn = ttk.Button(account_frame, text="View Private Keys", command=self.show_private_keys)
            key_btn.pack(anchor='w', pady=5)
            
            logout_btn = ttk.Button(frame, text="Log Out", command=self.logout)
            logout_btn.grid(row=3, column=0, columnspan=2, pady=20)
    
    # ---------------- Tabs: Wallet ----------------
    def setup_wallet_tab(self):
        frame = ttk.Frame(self.tab_wallet, padding=20)
        frame.pack(expand=True, fill='both')
        
        balance_frame = ttk.LabelFrame(frame, text="Balance")
        balance_frame.pack(fill='x', pady=10)
        
        self.balance_label = ttk.Label(balance_frame, text="Loading balance...", font=('Helvetica', 16, 'bold'))
        self.balance_label.pack(pady=10)
        
        send_frame = ttk.LabelFrame(frame, text="Send DIAC")
        send_frame.pack(fill='x', pady=10)
        
        ttk.Label(send_frame, text="Recipient address:").pack(anchor='w', pady=5)
        self.recipient_entry = ttk.Entry(send_frame, width=50)
        self.recipient_entry.pack(fill='x', pady=5)
        
        ttk.Label(send_frame, text="Amount:").pack(anchor='w', pady=5)
        self.amount_entry = ttk.Entry(send_frame, width=20)
        self.amount_entry.pack(anchor='w', pady=5)
        
        send_btn = ttk.Button(send_frame, text="Send", command=self.send_diac)
        send_btn.pack(anchor='w', pady=10)
        
        history_frame = ttk.LabelFrame(frame, text="Transaction History")
        history_frame.pack(fill='both', expand=True, pady=10)
        
        columns = ('timestamp', 'type', 'address', 'amount', 'status')
        self.history_tree = ttk.Treeview(history_frame, columns=columns, show='headings')
        self.history_tree.heading('timestamp', text='Date/Time')
        self.history_tree.heading('type', text='Type')
        self.history_tree.heading('address', text='Address')
        self.history_tree.heading('amount', text='Amount')
        self.history_tree.heading('status', text='Status')
        self.history_tree.column('timestamp', width=150)
        self.history_tree.column('type', width=100)
        self.history_tree.column('address', width=250)
        self.history_tree.column('amount', width=100)
        self.history_tree.column('status', width=100)
        scrollbar = ttk.Scrollbar(history_frame, orient='vertical', command=self.history_tree.yview)
        self.history_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        self.history_tree.pack(fill='both', expand=True)
    
    # ---------------- Tabs: Mining ----------------
    def setup_mining_tab(self):
        frame = ttk.Frame(self.tab_mining, padding=20)
        frame.pack(expand=True, fill='both')
        
        control_frame = ttk.LabelFrame(frame, text="Mining Control")
        control_frame.pack(fill='x', pady=10)
        
        self.mining_status_label = ttk.Label(control_frame, text="Status: Inactive", foreground="red")
        self.mining_status_label.pack(anchor='w', pady=10)
        
        self.mine_btn = ttk.Button(control_frame, text="Start Mining", command=self.toggle_mining)
        self.mine_btn.pack(anchor='w', pady=10)
        
        stats_frame = ttk.LabelFrame(frame, text="Mining Stats")
        stats_frame.pack(fill='both', expand=True, pady=10)
        
        self.rewards_label = ttk.Label(stats_frame, text="Total Rewards: 0 DIAC")
        self.rewards_label.pack(anchor='w', pady=5)
        self.rate_label = ttk.Label(stats_frame, text="Rate: 0 DIAC/hour")
        self.rate_label.pack(anchor='w', pady=5)
        self.challenges_label = ttk.Label(stats_frame, text="Completed Challenges: 0")
        self.challenges_label.pack(anchor='w', pady=5)
        self.efficiency_label = ttk.Label(stats_frame, text="Efficiency: 0%")
        self.efficiency_label.pack(anchor='w', pady=5)
    
    # ---------------- Tabs: Network ----------------
    def setup_network_tab(self):
        frame = ttk.Frame(self.tab_network, padding=20)
        frame.pack(expand=True, fill='both')
        
        net_stats_frame = ttk.LabelFrame(frame, text="Network Stats")
        net_stats_frame.pack(fill='x', pady=10)
        
        self.network_mode_label = ttk.Label(net_stats_frame, text=self._network_mode_label())
        self.network_mode_label.pack(anchor='w', pady=5)

        self.peers_label = ttk.Label(net_stats_frame, text="Connected Peers: 0")
        self.peers_label.pack(anchor='w', pady=5)
        
        self.fragments_label = ttk.Label(net_stats_frame, text="Synced Fragments: 0")
        self.fragments_label.pack(anchor='w', pady=5)
        
        self.sync_status_label = ttk.Label(net_stats_frame, text="MVS Status: Not synced")
        self.sync_status_label.pack(anchor='w', pady=5)
        
        discover_btn = ttk.Button(net_stats_frame, text="Discover Peers (URL)", command=self.discover_peers)
        discover_btn.pack(anchor='w', pady=10)

        reselect_btn = ttk.Button(net_stats_frame, text="Change Network (Central/Custom)", command=self.ask_network_mode)
        reselect_btn.pack(anchor='w', pady=5)

        # Add Peer manually
        add_frame = ttk.LabelFrame(frame, text="Add Peer")
        add_frame.pack(fill='x', pady=10)
        row = 0
        ttk.Label(add_frame, text="IP:").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        self.ip_entry = ttk.Entry(add_frame, width=20)
        self.ip_entry.grid(row=row, column=1, sticky='w', padx=5, pady=5)
        ttk.Label(add_frame, text="Port:").grid(row=row, column=2, sticky='w', padx=5, pady=5)
        self.port_entry = ttk.Entry(add_frame, width=10)
        self.port_entry.grid(row=row, column=3, sticky='w', padx=5, pady=5)
        ttk.Label(add_frame, text="Address (optional):").grid(row=row, column=4, sticky='w', padx=5, pady=5)
        self.address_entry = ttk.Entry(add_frame, width=34)
        self.address_entry.grid(row=row, column=5, sticky='w', padx=5, pady=5)
        add_btn = ttk.Button(add_frame, text="Add", command=self.add_peer)
        add_btn.grid(row=row, column=6, sticky='w', padx=5, pady=5)
        
        peers_frame = ttk.LabelFrame(frame, text="Known Peers")
        peers_frame.pack(fill='both', expand=True, pady=10)
        
        columns = ('ip', 'port', 'address', 'last_seen')
        self.peers_tree = ttk.Treeview(peers_frame, columns=columns, show='headings')
        self.peers_tree.heading('ip', text='IP')
        self.peers_tree.heading('port', text='Port')
        self.peers_tree.heading('address', text='Address')
        self.peers_tree.heading('last_seen', text='Last Seen')
        self.peers_tree.column('ip', width=140)
        self.peers_tree.column('port', width=80, anchor='center')
        self.peers_tree.column('address', width=360)
        self.peers_tree.column('last_seen', width=180)
        scrollbar = ttk.Scrollbar(peers_frame, orient='vertical', command=self.peers_tree.yview)
        self.peers_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        self.peers_tree.pack(fill='both', expand=True)
    
    # ---------------- Update loop ----------------
    def update_data(self):
        if self.is_logged_in:
            # Balance
            balance = self.dnc_adapter.get_balance()
            self.balance_label.config(text=f"{balance} DIAC")
            
            # History
            self.update_transaction_history()
            
            # Mining
            if self.mining_active:
                mining_stats = self.dnc_adapter.get_mining_stats()
                self.rewards_label.config(text=f"Total Rewards: {mining_stats['total_rewards']} DIAC")
                self.rate_label.config(text=f"Rate: {mining_stats['hourly_rate']} DIAC/hour")
                self.challenges_label.config(text=f"Completed Challenges: {mining_stats['completed_challenges']}")
                self.efficiency_label.config(text=f"Efficiency: {mining_stats['efficiency']}%")
            
            # Network
            net_stats = self.dnc_adapter.get_network_stats()
            self.peers_label.config(text=f"Connected Peers: {net_stats['connected_peers']}")
            self.fragments_label.config(text=f"Synced Fragments: {net_stats['synced_fragments']}")
            if net_stats['mvs_synced']:
                self.sync_status_label.config(text="MVS Status: Synced", foreground="green")
            else:
                self.sync_status_label.config(text="MVS Status: Not synced", foreground="red")
            
            # Peers list
            self.update_peers_list()
        
        # Keep the network label up-to-date
        self.network_mode_label.config(text=self._network_mode_label())
        self.root.after(5000, self.update_data)
    
    def update_transaction_history(self):
        for i in self.history_tree.get_children():
            self.history_tree.delete(i)
        transactions = self.dnc_adapter.get_recent_transactions()
        for tx in transactions:
            self.history_tree.insert('', 'end', values=(
                tx.get('timestamp', ''),
                tx.get('type', ''),
                tx.get('address', ''),
                tx.get('amount', ''),
                tx.get('status', '')
            ))
    
    def update_peers_list(self):
        for i in self.peers_tree.get_children():
            self.peers_tree.delete(i)
        peers = self.dnc_adapter.get_peers()
        for peer in peers:
            self.peers_tree.insert('', 'end', values=(
                peer.get('ip', ''),
                peer.get('port', ''),
                peer.get('address', ''),
                peer.get('last_seen', '')
            ))
    
    # ---------------- Actions ----------------
    def create_new_account(self):
        if not messagebox.askyesno("Confirm", "Create a new DIAC account? If you already have one, log in with your keys."):
            return
        if self.dnc_adapter.create_new_account():
            messagebox.showinfo("Success", f"Account created!\n\nAddress: {self.dnc_adapter.get_address()}\n\nKeep your private keys safe.")
            self.is_logged_in = True
            self.save_config()
            self.enable_tabs()
            self.setup_login_tab()
        else:
            messagebox.showerror("Error", "Account creation failed.")
    
    def login_with_keys(self):
        dialog = KeysDialog(self.root)
        self.root.wait_window(dialog.top)
        if dialog.result:
            success = self.dnc_adapter.login_with_keys(dialog.public_key, dialog.private_key)
            if success:
                messagebox.showinfo("Success", "Logged in successfully!")
                self.is_logged_in = True
                self.save_config()
                self.enable_tabs()
                self.setup_login_tab()
            else:
                messagebox.showerror("Error", "Invalid keys.")
    
    def show_private_keys(self):
        keys = {
            "address": self.dnc_adapter.get_address(),
            "public_key": self.dnc_adapter.get_public_key(),
            "private_key": self.dnc_adapter.get_private_key()
        }
        info_window = tk.Toplevel(self.root)
        info_window.title("Keys Info")
        info_window.geometry("600x400")
        info_window.transient(self.root)
        info_window.grab_set()
        frame = ttk.Frame(info_window, padding=20)
        frame.pack(fill='both', expand=True)
        warning_label = ttk.Label(frame, text="WARNING! Never share your private keys.", foreground="red", font=('Helvetica', 12, 'bold'))
        warning_label.pack(pady=10)
        key_frame = ttk.LabelFrame(frame, text="Keys")
        key_frame.pack(fill='both', expand=True, pady=10)
        ttk.Label(key_frame, text="Address:").pack(anchor='w', pady=5)
        address_entry = ttk.Entry(key_frame, width=70)
        address_entry.insert(0, keys['address'])
        address_entry.configure(state='readonly')
        address_entry.pack(fill='x', pady=5)
        ttk.Label(key_frame, text="Public Key:").pack(anchor='w', pady=5)
        public_entry = ttk.Entry(key_frame, width=70)
        public_entry.insert(0, keys['public_key'])
        public_entry.configure(state='readonly')
        public_entry.pack(fill='x', pady=5)
        ttk.Label(key_frame, text="Private Key:").pack(anchor='w', pady=5)
        private_entry = ttk.Entry(key_frame, width=70, show="*")
        private_entry.insert(0, keys['private_key'])
        private_entry.configure(state='readonly')
        private_entry.pack(fill='x', pady=5)
        def toggle_private_key():
            if private_entry.cget('show') == '*':
                private_entry.configure(show='')
                toggle_btn.configure(text="Hide Private Key")
            else:
                private_entry.configure(show='*')
                toggle_btn.configure(text="Show Private Key")
        toggle_btn = ttk.Button(key_frame, text="Show Private Key", command=toggle_private_key)
        toggle_btn.pack(anchor='w', pady=10)
        ttk.Button(frame, text="Close", command=info_window.destroy).pack(pady=10)
        self.root.wait_window(info_window)
    
    def logout(self):
        if not messagebox.askyesno("Confirm", "Log out?"):
            return
        if self.mining_active:
            self.toggle_mining()
        self.dnc_adapter.logout()
        self.is_logged_in = False
        self.disable_tabs()
        self.setup_login_tab()
        if self.config_path.exists():
            try:
                os.remove(self.config_path)
                self.config = {}
            except Exception:
                pass
    
    def send_diac(self):
        recipient = self.recipient_entry.get().strip()
        amount_str = self.amount_entry.get().strip()
        if not recipient:
            messagebox.showerror("Error", "Recipient address is required.")
            return
        try:
            amount = float(amount_str)
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Amount must be a positive number.")
            return
        if not messagebox.askyesno("Confirm", f"Send {amount} DIAC to {recipient}?"):
            return
        success, message = self.dnc_adapter.send_diac(recipient, amount)
        if success:
            messagebox.showinfo("Success", f"Transaction sent!\n\n{message}")
            self.recipient_entry.delete(0, 'end')
            self.amount_entry.delete(0, 'end')
            self.update_transaction_history()
        else:
            messagebox.showerror("Error", f"Transaction failed:\n\n{message}")
    
    def toggle_mining(self):
        if not self.mining_active:
            success = self.dnc_adapter.start_mining()
            if success:
                self.mining_active = True
                self.mining_status_label.config(text="Status: Active", foreground="green")
                self.mine_btn.config(text="Stop Mining")
                messagebox.showinfo("Mining", "Mining started.")
            else:
                messagebox.showerror("Error", "Could not start mining.")
        else:
            self.dnc_adapter.stop_mining()
            self.mining_active = False
            self.mining_status_label.config(text="Status: Inactive", foreground="red")
            self.mine_btn.config(text="Start Mining")
            messagebox.showinfo("Mining", "Mining stopped.")
    
    def discover_peers(self):
        count = self.dnc_adapter.discover_peers()
        messagebox.showinfo("Discovery", f"Found {count} new peers (if DNC_DISCOVERY_URL is configured).")
        self.update_peers_list()

    def add_peer(self):
        ip = self.ip_entry.get().strip()
        port = self.port_entry.get().strip()
        address = self.address_entry.get().strip()
        if not ip or not port:
            messagebox.showerror("Error", "IP and Port are required.")
            return
        try:
            ok = self.dnc_adapter.add_peer(ip, int(port), address)
            if ok:
                messagebox.showinfo("Peer", "Peer added.")
                self.ip_entry.delete(0, 'end')
                self.port_entry.delete(0, 'end')
                self.address_entry.delete(0, 'end')
                self.update_peers_list()
            else:
                messagebox.showwarning("Peer", "Peer already exists or data invalid.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not add peer: {e}")
    
    # ---------------- Tabs state ----------------
    def enable_tabs(self):
        self.tab_control.tab(1, state='normal')
        self.tab_control.tab(2, state='normal')
        self.tab_control.tab(3, state='normal')
        self.tab_control.select(1)
    
    def disable_tabs(self):
        self.tab_control.tab(1, state='disabled')
        self.tab_control.tab(2, state='disabled')
        self.tab_control.tab(3, state='disabled')
        self.tab_control.select(0)
    
    def on_closing(self):
        if self.mining_active:
            self.dnc_adapter.stop_mining()
        if self.is_logged_in:
            self.save_config()
        self.root.destroy()

    # ---------------- Helpers ----------------
    def _network_mode_label(self):
        mode = self.config.get('network_mode', 'unset')
        port = self.config.get('listen_port', 'unset')
        if mode == 'central':
            return f"Network: Central DIAC (port {DEFAULT_DIAC_PORT})"
        elif mode == 'custom':
            return f"Network: Custom DIAC subnet (port {port})"
        else:
            return "Network: not configured"


class KeysDialog:
    """Dialog to input keys"""
    def __init__(self, parent):
        self.top = tk.Toplevel(parent)
        self.top.title("Enter Keys")
        self.top.geometry("600x250")
        self.top.transient(parent)
        self.top.grab_set()
        frame = ttk.Frame(self.top, padding=20)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text="Public Key:").pack(anchor='w', pady=5)
        self.public_entry = ttk.Entry(frame, width=70)
        self.public_entry.pack(fill='x', pady=5)
        ttk.Label(frame, text="Private Key:").pack(anchor='w', pady=5)
        self.private_entry = ttk.Entry(frame, width=70, show="*")
        self.private_entry.pack(fill='x', pady=5)
        btn_frame = ttk.Frame(frame); btn_frame.pack(fill='x', pady=20)
        ttk.Button(btn_frame, text="Cancel", command=self.cancel).pack(side='right', padx=5)
        ttk.Button(btn_frame, text="OK", command=self.ok).pack(side='right', padx=5)
        self.result = False
        self.public_key = ""
        self.private_key = ""
    
    def ok(self):
        self.public_key = self.public_entry.get().strip()
        self.private_key = self.private_entry.get().strip()
        if not self.public_key or not self.private_key:
            messagebox.showerror("Error", "Both keys are required.")
            return
        self.result = True
        self.top.destroy()
    
    def cancel(self):
        self.result = False
        self.top.destroy()


class NetworkModeDialog:
    """Dialog to choose Central DIAC (port 369) or create your own DIAC subnet (custom port)."""
    def __init__(self, parent):
        self.top = tk.Toplevel(parent)
        self.top.title("Choose DIAC Network Mode")
        self.top.geometry("560x320")
        self.top.transient(parent)
        self.top.grab_set()

        self.ok = False
        self.mode = 'central'
        self.port = DEFAULT_DIAC_PORT
        self.custom_port = None

        frame = ttk.Frame(self.top, padding=20)
        frame.pack(fill='both', expand=True)

        title = ttk.Label(frame, text="Join Central DIAC or Create Your Own Subnet", font=('Helvetica', 12, 'bold'))
        title.pack(anchor='w', pady=5)

        desc = ("Central DIAC (port 369): everyone uses the same port. "
                "Nodes on the same LAN will auto-discover each other. Over the Internet, "
                "you still need to share IPs or use a discovery URL.\n\n"
                "Create your own DIAC subnet: choose a custom port to isolate your network. "
                "Think of it as a private DIAC sub-network.")
        ttk.Label(frame, text=desc, wraplength=500, justify='left').pack(anchor='w', pady=10)

        self.mode_var = tk.StringVar(value='central')

        central_rb = ttk.Radiobutton(frame, text=f"Join Central DIAC (port {DEFAULT_DIAC_PORT})",
                                     variable=self.mode_var, value='central')
        central_rb.pack(anchor='w', pady=5)

        custom_rb = ttk.Radiobutton(frame, text="Create my own DIAC subnet (custom port)",
                                    variable=self.mode_var, value='custom')
        custom_rb.pack(anchor='w', pady=5)

        port_row = ttk.Frame(frame); port_row.pack(anchor='w', pady=8, fill='x')
        ttk.Label(port_row, text="Custom port:").pack(side='left')
        self.port_entry = ttk.Entry(port_row, width=10)
        self.port_entry.insert(0, "5369")
        self.port_entry.pack(side='left', padx=6)

        btn_frame = ttk.Frame(frame); btn_frame.pack(fill='x', pady=16)
        ttk.Button(btn_frame, text="Cancel", command=self.cancel).pack(side='right', padx=5)
        ttk.Button(btn_frame, text="OK", command=self.ok_clicked).pack(side='right', padx=5)

    def ok_clicked(self):
        self.mode = self.mode_var.get()
        if self.mode == 'central':
            self.port = DEFAULT_DIAC_PORT
            self.ok = True
            self.top.destroy()
        else:
            val = self.port_entry.get().strip()
            try:
                p = int(val)
                if not (1 <= p <= 65535):
                    raise ValueError
                self.custom_port = p
                self.ok = True
                self.top.destroy()
            except Exception:
                messagebox.showerror("Error", "Invalid custom port. Use 1-65535.")

    def cancel(self):
        self.ok = False
        self.top.destroy()
