# diac_dnc_client_core.py
# Core with real-network orientation: no fake peers, optional discovery URL, simple mining placeholder.
import time
import random
import json
import hashlib
import base64
import os
import threading
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path

class DNCAuxiliary:
    """Simplified DNC client core for use with the GUI, oriented to real peers only."""
    
    def __init__(self, mode="new", public_key=None, private_key=None):
        self.base_path = Path.home() / '.diac_dnc'
        self.base_path.mkdir(exist_ok=True)
        
        self.peers = []
        self.mining_stats = {
            "total_rewards": 0,
            "hourly_rate": 0,
            "completed_challenges": 0,
            "efficiency": 0
        }
        
        self.ledger_fragment = {
            "balances": {},
            "transactions": []
        }
        
        self.recent_transactions = []
        
        # Keys
        if mode == "new":
            self._generate_new_keys()
        elif mode == "existing":
            if not public_key or not private_key:
                raise ValueError("Both keys are required for 'existing' mode")
            self.public_key = public_key
            self.private_key = private_key
        else:
            raise ValueError("mode must be 'new' or 'existing'")
        
        # Address
        self.address = self._derive_address_from_pubkey()
        
        # Initial test balance
        if self.address not in self.ledger_fragment["balances"]:
            self.ledger_fragment["balances"][self.address] = 100.0
        
        # Load peers (empty if none)
        self._load_or_init_peers()
        
        # Background placeholders
        self._start_background_tasks()
    
    # ---------------- Keys ----------------
    def _generate_new_keys(self):
        seed = os.urandom(32)
        self.private_key = base64.b64encode(seed).decode('utf-8')
        h = hashlib.sha256()
        h.update(seed)
        h.update(b"DNC-pubkey-derivation")
        pub_seed = h.digest()
        self.public_key = base64.b64encode(pub_seed).decode('utf-8')
    
    def _derive_address_from_pubkey(self):
        h = hashlib.sha256()
        h.update(self.public_key.encode('utf-8'))
        digest = h.hexdigest()
        return f"DNC-{digest[:40]}"
    
    # ---------------- Peers storage ----------------
    def _peers_file(self):
        return self.base_path / 'peers.json'
    
    def _save_peers(self):
        with open(self._peers_file(), 'w') as f:
            json.dump(self.peers, f, indent=2)
    
    def _load_or_init_peers(self):
        pf = self._peers_file()
        if pf.exists():
            try:
                with open(pf, 'r') as f:
                    self.peers = json.load(f)
            except Exception:
                self.peers = []
                self._save_peers()
        else:
            self.peers = []
            self._save_peers()

    def add_peer(self, ip: str, port: int, address: str = ""):
        """Add a real peer (IP/port[/address]) and persist to peers.json."""
        ip = (ip or "").strip()
        port = int(port)
        address = (address or "").strip()
        if not ip or not port:
            return False
        if not any((p.get("ip") == ip and int(p.get("port", 0)) == port) for p in self.peers):
            if not address:
                derived = hashlib.sha256(f"{ip}:{port}".encode()).hexdigest()[:40]
                address = f"DNC-{derived}"
            new_peer = {
                "address": address,
                "ip": ip,
                "port": port,
                "last_seen": "1970-01-01T00:00:00"
            }
            self.peers.append(new_peer)
            self._save_peers()
            return True
        return False
    
    # ---------------- Background ----------------
    def _start_background_tasks(self):
        t = threading.Thread(target=self._placeholder_sync, daemon=True)
        t.start()

    def _placeholder_sync(self):
        while True:
            time.sleep(30)

    # ---------------- Wallet / TX ----------------
    def get_address(self):
        return self.address
    
    def get_public_key(self):
        return self.public_key
    
    def get_private_key(self):
        return self.private_key
    
    def get_balance(self):
        return self.ledger_fragment["balances"].get(self.address, 0)
    
    def send_transaction(self, recipient, amount):
        if not recipient.startswith("DNC-"):
            raise ValueError("Recipient address must start with 'DNC-'")
        if amount <= 0:
            raise ValueError("Amount must be positive")
        balance = self.get_balance()
        if amount > balance:
            raise ValueError(f"Insufficient balance. You have {balance} DIAC")
        
        txid = hashlib.sha256(f"{self.address}-{recipient}-{amount}-{time.time()}".encode()).hexdigest()
        
        self.ledger_fragment["balances"][self.address] -= amount
        if recipient in self.ledger_fragment["balances"]:
            self.ledger_fragment["balances"][recipient] += amount
        else:
            self.ledger_fragment["balances"][recipient] = amount
        
        tx = {
            "txid": txid,
            "from": self.address,
            "to": recipient,
            "amount": amount,
            "timestamp": datetime.now().isoformat()
        }
        self.ledger_fragment["transactions"].append(tx)
        
        recent_tx = {
            "timestamp": datetime.now().isoformat(),
            "type": "Send",
            "address": recipient,
            "amount": amount,
            "status": "Confirmed"
        }
        self.recent_transactions.insert(0, recent_tx)
        if len(self.recent_transactions) > 20:
            self.recent_transactions = self.recent_transactions[:20]
        
        return txid
    
    def perform_mining_cycle(self):
        """Local mining placeholder (no fake network)."""
        success = random.random() < 0.6
        if success:
            reward = round(random.uniform(0.05, 0.5), 4)
            self.ledger_fragment["balances"][self.address] = self.get_balance() + reward
            self.mining_stats["total_rewards"] += reward
            self.mining_stats["completed_challenges"] += 1
            hourly_estimate = reward * 15
            self.mining_stats["hourly_rate"] = round(hourly_estimate, 2)
            total_attempts = self.mining_stats.get("total_attempts", 0) + 1
            self.mining_stats["total_attempts"] = total_attempts
            self.mining_stats["efficiency"] = round((self.mining_stats["completed_challenges"] / total_attempts) * 100, 1)
            recent_tx = {
                "timestamp": datetime.now().isoformat(),
                "type": "Mining",
                "address": "System",
                "amount": reward,
                "status": "Confirmed"
            }
            self.recent_transactions.insert(0, recent_tx)
            if len(self.recent_transactions) > 20:
                self.recent_transactions = self.recent_transactions[:20]
            return True
        else:
            total_attempts = self.mining_stats.get("total_attempts", 0) + 1
            self.mining_stats["total_attempts"] = total_attempts
            self.mining_stats["efficiency"] = round((self.mining_stats["completed_challenges"] / total_attempts) * 100, 1)
            return False
    
    def get_mining_stats(self):
        return {
            "total_rewards": round(self.mining_stats["total_rewards"], 4),
            "hourly_rate": round(self.mining_stats["hourly_rate"], 4),
            "completed_challenges": self.mining_stats["completed_challenges"],
            "efficiency": self.mining_stats.get("efficiency", 0)
        }
    
    # ---------------- Network API ----------------
    def get_recent_transactions(self):
        return self.recent_transactions
    
    def get_peers_list(self):
        return self.peers
    
    def get_network_stats(self):
        """Placeholder only; adapter computes real connectivity via TCP ping."""
        return {"connected_peers": 0, "synced_fragments": 0, "mvs_synced": False}
    
    def discover_peers(self):
        """
        Discover peers from a REAL source (public JSON).
        Uses environment variable DNC_DISCOVERY_URL (GET) returning a list of {ip, port, address?}.
        """
        url = os.environ.get("DNC_DISCOVERY_URL", "").strip()
        if not url:
            return 0
        try:
            with urllib.request.urlopen(url, timeout=5) as resp:
                data = resp.read()
                payload = json.loads(data.decode("utf-8"))
                discovered = 0
                for entry in payload:
                    ip = (entry.get("ip") or "").strip()
                    port = entry.get("port")
                    address = (entry.get("address") or "").strip()
                    if not ip or port is None:
                        continue
                    if not any((p.get("ip") == ip and int(p.get("port", 0)) == int(port)) for p in self.peers):
                        if not address:
                            derived = hashlib.sha256(f"{ip}:{port}".encode()).hexdigest()[:40]
                            address = f"DNC-{derived}"
                        self.peers.append({
                            "address": address,
                            "ip": ip,
                            "port": int(port),
                            "last_seen": "1970-01-01T00:00:00"
                        })
                        discovered += 1
                if discovered:
                    self._save_peers()
                return discovered
        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, TimeoutError):
            return 0
