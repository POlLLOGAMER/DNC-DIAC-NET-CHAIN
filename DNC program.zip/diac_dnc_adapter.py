# diac_dnc_adapter.py
import threading
import time
import json
import socket
from datetime import datetime
from pathlib import Path

from diac_dnc_client_core import DNCAuxiliary

DEFAULT_DIAC_PORT = 369  # Central DIAC "network" port (optional on some OS: may require elevated perms)

class DNCAdapter:
    """Adapter between the GUI and the core DNC functionality, with real TCP ping and LAN discovery."""
    
    def __init__(self):
        self.dnc = None
        self.mining_thread = None
        self.mining_active = False
        self.load_path = Path.home() / '.diac_dnc'
        self.load_path.mkdir(exist_ok=True)

        # Ping server
        self.listen_port = None
        self._server_thread = None
        self._server_socket = None

        # Multicast discovery
        self._mc_send_thread = None
        self._mc_recv_thread = None
        self._stop_mc = threading.Event()
        self._multicast_group = ('239.255.124.69', 39369)  # LAN scope multicast
        self._hidden_id = None  # internal, not shown

    # ----------------- Network bootstrap -----------------
    def configure_network(self, port: int):
        """Start TCP ping server + start LAN discovery on the selected port (central or custom)."""
        self.start_ping_server(port)
        self.start_multicast_discovery(port)

    def start_ping_server(self, port: int):
        """Start the TCP server that answers pings on the given port."""
        if self._server_thread and self._server_thread.is_alive():
            return  # Already running
        self.listen_port = int(port)
        self._server_thread = threading.Thread(target=self._start_ping_server, daemon=True)
        self._server_thread.start()

    def _start_ping_server(self):
        try:
            self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_socket.bind(('0.0.0.0', self.listen_port))
            self._server_socket.listen()
            print(f"[DNCAdapter] Ping server listening on port {self.listen_port}")
            while True:
                conn, addr = self._server_socket.accept()
                try:
                    data = conn.recv(1024)
                    if data == b"ping":
                        conn.sendall(b"pong")
                finally:
                    conn.close()
        except Exception as e:
            print(f"[DNCAdapter] Ping server error: {e}")

    def _get_local_ip(self) -> str:
        try:
            # Discover outward-facing local IP (works without internet connection as well)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def start_multicast_discovery(self, port: int):
        """Start LAN multicast discovery. Nodes on the same LAN & port will auto-find each other."""
        if self._mc_send_thread and self._mc_send_thread.is_alive():
            return
        self._stop_mc.clear()
        self._mc_send_thread = threading.Thread(target=self._mc_sender, args=(int(port),), daemon=True)
        self._mc_recv_thread = threading.Thread(target=self._mc_receiver, args=(int(port),), daemon=True)
        self._mc_send_thread.start()
        self._mc_recv_thread.start()

    def stop_multicast_discovery(self):
        """Stop LAN discovery threads."""
        self._stop_mc.set()

    def _mc_sender(self, port: int):
        """Periodically announce our presence on LAN via multicast."""
        ttl_bin = 1 .to_bytes(1, 'little')
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl_bin)
            ip = self._get_local_ip()
            while not self._stop_mc.is_set():
                # Message format: DNCHELLO ip port address
                addr = self.get_address() or ""
                msg = f"DNCHELLO {ip} {port} {addr}".encode('utf-8')
                s.sendto(msg, self._multicast_group)
                time.sleep(3)
        except Exception as e:
            print(f"[DNCAdapter] Multicast sender error: {e}")

    def _mc_receiver(self, port: int):
        """Listen for multicast announcements and add peers that share our selected port."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('', self._multicast_group[1]))
            mreq = socket.inet_aton(self._multicast_group[0]) + socket.inet_aton('0.0.0.0')
            s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            while not self._stop_mc.is_set():
                data, _ = s.recvfrom(2048)
                try:
                    text = data.decode('utf-8', errors='ignore')
                    if not text.startswith("DNCHELLO "):
                        continue
                    _, ip, p_str, address = text.split(" ", 3)
                    p = int(p_str)
                    if p != port:
                        continue  # different subnet (custom port)
                    # Don't add self
                    if ip == self._get_local_ip() and p == self.listen_port:
                        continue
                    self.add_peer(ip, p, address.strip())
                except Exception:
                    continue
        except Exception as e:
            print(f"[DNCAdapter] Multicast receiver error: {e}")

    def ping_peers_real(self, peers):
        """Return how many peers are alive via real TCP ping."""
        alive = 0
        for peer in peers:
            try:
                ip = peer.get("ip")
                port = int(peer.get("port")) if peer.get("port") is not None else None
                if not ip or not port:
                    continue
                with socket.create_connection((ip, port), timeout=1.8) as s:
                    s.sendall(b"ping")
                    resp = s.recv(1024)
                    if resp == b"pong":
                        alive += 1
                        peer["last_seen"] = datetime.now().isoformat()
            except Exception:
                continue
        return alive

    # ----------------- Hidden identifier -----------------
    def _ensure_hidden_id(self):
        """Create a hidden identifier bound to our public key and selected port."""
        if self._hidden_id or not self.dnc or self.listen_port is None:
            return
        import hashlib
        pk = self.dnc.get_public_key() or ""
        seed = f"{pk}|{self.listen_port}".encode('utf-8')
        self._hidden_id = hashlib.sha256(seed).hexdigest()[:12]

    def get_hidden_id(self):
        self._ensure_hidden_id()
        return self._hidden_id or ""

    # ----------------- Session / account -----------------
    def create_new_account(self):
        try:
            self.dnc = DNCAuxiliary(mode="new")
            self._ensure_hidden_id()
            return True
        except Exception as e:
            print(f"Error creating account: {e}")
            return False
    
    def login_with_keys(self, public_key, private_key):
        try:
            self.dnc = DNCAuxiliary(mode="existing", public_key=public_key, private_key=private_key)
            self._ensure_hidden_id()
            return True
        except Exception as e:
            print(f"Error logging in: {e}")
            return False
    
    def logout(self):
        if self.mining_active:
            self.stop_mining()
        self.dnc = None
    
    # ----------------- Keys -----------------
    def get_address(self):
        if not self.dnc:
            return ""
        return self.dnc.get_address()
    
    def get_public_key(self):
        if not self.dnc:
            return ""
        return self.dnc.get_public_key()
    
    def get_private_key(self):
        if not self.dnc:
            return ""
        return self.dnc.get_private_key()
    
    def get_keys_info(self):
        if not self.dnc:
            return {"address": "", "public_key": "", "private_key": ""}
        return {
            "address": self.dnc.get_address(),
            "public_key": self.dnc.get_public_key(),
            "private_key": self.dnc.get_private_key()
        }
    
    # ----------------- Wallet -----------------
    def get_balance(self):
        if not self.dnc:
            return 0
        return self.dnc.get_balance()
    
    def send_diac(self, recipient, amount):
        if not self.dnc:
            return False, "No active session"
        try:
            txid = self.dnc.send_transaction(recipient, amount)
            return True, f"Transaction sent. ID: {txid[:8]}..."
        except Exception as e:
            return False, str(e)
    
    # ----------------- Mining -----------------
    def start_mining(self):
        if not self.dnc or self.mining_active:
            return False
        self.mining_active = True
        self.mining_thread = threading.Thread(target=self._mining_worker, daemon=True)
        self.mining_thread.start()
        return True
    
    def stop_mining(self):
        self.mining_active = False
        if self.mining_thread:
            self.mining_thread.join(timeout=1.0)
            self.mining_thread = None
    
    def _mining_worker(self):
        while self.mining_active and self.dnc:
            try:
                self.dnc.perform_mining_cycle()
                time.sleep(2)
            except Exception as e:
                print(f"Mining cycle error: {e}")
                time.sleep(5)
    
    def get_mining_stats(self):
        if not self.dnc:
            return {
                "total_rewards": 0,
                "hourly_rate": 0,
                "completed_challenges": 0,
                "efficiency": 0
            }
        return self.dnc.get_mining_stats()
    
    # ----------------- Network -----------------
    def get_network_stats(self):
        """Real stats: counts only peers that respond to TCP ping."""
        if not self.dnc:
            return {"connected_peers": 0, "synced_fragments": 0, "mvs_synced": False}
        peers = self.dnc.get_peers_list()
        active = self.ping_peers_real(peers)
        return {"connected_peers": active, "synced_fragments": 0, "mvs_synced": False}
    
    def get_recent_transactions(self):
        if not self.dnc:
            return []
        return self.dnc.get_recent_transactions()
    
    def get_peers(self):
        if not self.dnc:
            return []
        return self.dnc.get_peers_list()

    def add_peer(self, ip: str, port: int, address: str = ""):
        """Add a peer (IP/port[/address]) via core."""
        if not self.dnc:
            return False
        try:
            return self.dnc.add_peer(ip=ip, port=int(port), address=address)
        except Exception as e:
            print(f"Error adding peer: {e}")
            return False
    
    def discover_peers(self):
        """Optional: discover peers via public URL if configured (DNC_DISCOVERY_URL)."""
        if not self.dnc:
            return 0
        return self.dnc.discover_peers()
